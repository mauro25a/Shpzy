package com.example.ecommerceapp;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class HomeFragment extends Fragment implements View.OnClickListener{

    TextView recentlyViewedTV;
    ItemDb db;
    int firstVisiblePosition;
    EditText searchBar;
    Button invisibleSearchBtn;
    HorizontalScrollView horizontalScrollView;
    HorizontalScrollView horizontalScrollView02;
    LinearLayout linearLayout; //linearLayout nell'horizontalScrollView
    LinearLayout categoryLinearLayout;
    BottomNavigationView navView;
    String itemIdRecommended;
    String categoryRecommended02;
    String categorySelected;
    int blue;

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("key", String.valueOf(firstVisiblePosition));
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            firstVisiblePosition = Integer.parseInt(savedInstanceState.getString("key"));
        }

        FragmentActivity context = getActivity();
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        navView = (BottomNavigationView) rootView.findViewById(R.id.bottom_navigation);

        db = new ItemDb(context);
        ArrayList<HashMap<String, String>> itemIds = new ArrayList<>();

        String categoryRecommended = HomeActivity.categoryRecommended;

        if(categoryRecommended.equals("")) itemIds = db.GetItems();
        else itemIds = db.GetRecommendedItems(categoryRecommended);

        ArrayList<HashMap<String, String>> itemsRecommended = new ArrayList<>();
        itemsRecommended = db.GetRecommendedItems(HomeActivity.categoryRecommended);
        int itemsRecommendedSize = itemsRecommended.size();

        ImageView imageRecommendedIV = (ImageView) rootView.findViewById(R.id.itemImageRecommended);
        TextView nameRecommendedTV = (TextView) rootView.findViewById(R.id.itemNameRecommended);
        TextView categoryRecommendedTV = (TextView) rootView.findViewById(R.id.itemCategoryRecommended);
        TextView priceRecommendedTV = (TextView) rootView.findViewById(R.id.itemPriceRecommended);

        //richiamo così il metodo setOnClick implementato in questa classe
        imageRecommendedIV.setOnClickListener(this);
        nameRecommendedTV.setOnClickListener(this);
        categoryRecommendedTV.setOnClickListener(this);
        priceRecommendedTV.setOnClickListener(this);

        Random r = new Random();
        if(itemsRecommendedSize != 0) {
            HashMap<String, String> itemRecommended = itemsRecommended.get(0); //ottengo il primo elemento nella lista dei consigliati
        } else{
            itemsRecommended = db.GetItems();
            HashMap<String, String> itemRecommended = itemsRecommended.get(0); //ottengo il primo elemento nella lista dei consigliati
        }
        HashMap<String, String> itemRecommended = itemsRecommended.get(0); //ottengo il primo elemento nella lista dei consigliati
        itemIdRecommended = itemRecommended.get("itemid");
        categoryRecommended02 = itemRecommended.get("category");
        categorySelected = categoryRecommended02;
        imageRecommendedIV.setImageResource(Integer.parseInt(itemRecommended.get("image_id")));
        nameRecommendedTV.setText(itemRecommended.get("name"));
        categoryRecommendedTV.setText(itemRecommended.get("category"));
        priceRecommendedTV.setText(itemRecommended.get("price") + " €");

        searchBar = (EditText) rootView.findViewById(R.id.search_edit_text);
        invisibleSearchBtn = (Button) rootView.findViewById(R.id.button_search);

        String email = HomeActivity.email;

        ArrayList<HashMap<String, String>> items = db.GetItems();
        linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);

        ArrayList<HashMap<String, String>> cronologyItems = db.getCronologyUser(email);

        if (cronologyItems.size() == 0) {
            UserDb userDb = new UserDb(context);
            ArrayList<HashMap<String,String>> userList = userDb.GetusersByid(email);
            recentlyViewedTV = (TextView) rootView.findViewById(R.id.recentlyViewed);
            recentlyViewedTV.setText("Welcome " + userList.get(0).get("username") + "!");
            recentlyViewedTV.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        }

        //implementazione horizontal scrollview per gli elementi recentemente visualizzati
        for (int i = 0; i<cronologyItems.size(); i++) {
            View listItem = getLayoutInflater().inflate(R.layout.horizontal_element, null); //singolo elemento orizzontale

            String itemid = cronologyItems.get(i).get("itemid");
            String itemImage = cronologyItems.get(i).get("image_id");
            String itemName = cronologyItems.get(i).get("name");
            String itemPrice =  cronologyItems.get(i).get("price");

            ImageView image = listItem.findViewById(R.id.itemImageHorizontal);
            image.setImageResource(Integer.parseInt(itemImage));

            TextView name = listItem.findViewById(R.id.ItemNameHorizontal);
            name.setText(itemName);

            TextView price = listItem.findViewById(R.id.itemPriceHorizontal);
            price.setText(itemPrice + " €");

            linearLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

            int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
            int cellWidth = screenWidth/3+100;
            int cellHeight = cellWidth+250;

            listItem.setPadding(4, 0, 0, 0);

            ConstraintLayout constraintLayout = listItem.findViewById(R.id.constraintLayout);
            constraintLayout.setLayoutParams(new LinearLayout.LayoutParams(cellWidth,cellHeight));

            listItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment selectedFragment = new ItemPageFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("itemid", itemid);

                    FragmentManager fragmentManager = getParentFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    Fragment itemFragment = new ItemPageFragment();
                    itemFragment.setArguments(bundle);
                    fragmentTransaction.replace(R.id.fragment_container, itemFragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            });
            linearLayout.addView(listItem);
        }

        horizontalScrollView = (HorizontalScrollView) rootView.findViewById(R.id.horizontalScrollView);
        horizontalScrollView.addView(linearLayout);

        blue = Color.parseColor("#40CAF4");

        //implementazione horizontalscroll view per le categorie
        categoryLinearLayout = new LinearLayout(context);
        categoryLinearLayout.setOrientation(LinearLayout.HORIZONTAL);

        ItemDb itemDb = new ItemDb(context);

        //verrano visualizzate solo le categorie che hanno articoli in vendita
        ArrayList<HashMap<String, String>> categoryList = itemDb.GetCategories02();

        for (int i = 0; i<categoryList.size(); i++) {
            View categoryElement = getLayoutInflater().inflate(R.layout.category_element, null);

            String category = categoryList.get(i).get("category");

            Button categoryBtn = (Button) categoryElement.findViewById(R.id.categoryBTN);
            categoryBtn.setText(category);

            categoryLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

            categoryElement.setPadding(4, 0, 0, 0);

            LinearLayout linearLayout = categoryElement.findViewById(R.id.frameLayout04);

            //metodo usato per settare la larghezza di ogni button della category (categoryBtn) dopo che viene disegnato su schermo,
            // per recupere, così il valore di width e height di categoryBtn
            categoryBtn.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    int cellWidth = categoryBtn.getWidth();
                    int cellHeight = categoryBtn.getHeight();
                    linearLayout.setLayoutParams(new LinearLayout.LayoutParams(cellWidth + 30,cellHeight));
                    categoryBtn.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                }
            });

            categoryBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    categorySelected = (String) categoryBtn.getText();
                    showCategoryElementsSelected(rootView, context);
                    Drawable buttonBackground = getResources().getDrawable(R.drawable.btn_app02);
                    Drawable buttonBackgroundNormal = getResources().getDrawable(R.drawable.categories_btn);

                    int numberButtons = categoryLinearLayout.getChildCount();
                    for(int i=0; i<numberButtons; i++){
                        View view = categoryLinearLayout.getChildAt(i);
                        if (view instanceof Button) {
                            Button btn = (Button) view;
                            btn.setBackground(buttonBackgroundNormal);
                        } else if (view instanceof LinearLayout) {
                            LinearLayout linearLayout = (LinearLayout) view;
                            Button btn = (Button) linearLayout.getChildAt(0);
                            btn.setBackground(buttonBackgroundNormal);
                        }
                    }
                    categoryBtn.setBackground(buttonBackground); //setto categoryBtn di colore blu chiaro
                }
            });
            categoryLinearLayout.addView(categoryElement);
        }

        HorizontalScrollView categoryHorizontalSV = (HorizontalScrollView) rootView.findViewById(R.id.categoryHorizontalSCrollView);
        categoryHorizontalSV.addView(categoryLinearLayout);

        showCategoryElementsSelected(rootView, context);

        invisibleSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment selectedFragment = null;

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment searchFragment = new SearchFragment();
                fragmentTransaction.replace(R.id.fragment_container, searchFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return rootView;
    }

    private void showCategoryElementsSelected(View rootview, Context context) {
        LinearLayout linearLayout02;
        linearLayout02 = new LinearLayout(context);
        linearLayout02.setOrientation(LinearLayout.HORIZONTAL);

        ArrayList<HashMap<String, String>> categorySelectedElements = db.GetItemsCategory(categorySelected);

        //implementazione horizontal scrollview per gli elementi corrispondenti alla categoria selezionata
        for (int i = 0; i<categorySelectedElements.size(); i++) {
            View listItem = getLayoutInflater().inflate(R.layout.horizontal_element, null); //singolo elemento orizzontale

            String itemid = categorySelectedElements.get(i).get("itemid");
            String itemImage = categorySelectedElements.get(i).get("image_id");
            String itemName = categorySelectedElements.get(i).get("name");
            String itemPrice =  categorySelectedElements.get(i).get("price");

            ImageView image = listItem.findViewById(R.id.itemImageHorizontal);
            image.setImageResource(Integer.parseInt(itemImage));

            TextView name = listItem.findViewById(R.id.ItemNameHorizontal);
            name.setText(itemName);

            TextView price = listItem.findViewById(R.id.itemPriceHorizontal);
            price.setText(itemPrice + " €");

            linearLayout02.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

            int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
            int cellWidth = screenWidth/3+100;
            int cellHeight = cellWidth+250;

            listItem.setPadding(4, 0, 0, 0);

            ConstraintLayout constraintLayout = listItem.findViewById(R.id.constraintLayout);
            constraintLayout.setLayoutParams(new LinearLayout.LayoutParams(cellWidth,cellHeight));

            listItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment selectedFragment = new ItemPageFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("itemid", itemid);

                    FragmentManager fragmentManager = getParentFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    Fragment itemFragment = new ItemPageFragment();
                    itemFragment.setArguments(bundle);
                    fragmentTransaction.replace(R.id.fragment_container, itemFragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            });
            linearLayout02.addView(listItem);
        }
        horizontalScrollView02 = (HorizontalScrollView) rootview.findViewById(R.id.categoryElementsHoriz);
        horizontalScrollView02.removeAllViews();
        horizontalScrollView02.addView(linearLayout02);
        horizontalScrollView02.scrollTo(0,0); //imposta la scrollview all'inizio
    }

    public void recommendedPressed (String itemId){
        Bundle bundle = new Bundle();
        bundle.putString("itemid", itemId);

        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        Fragment itemFragment = new ItemPageFragment();
        itemFragment.setArguments(bundle);
        fragmentTransaction.add(R.id.fragment_container, itemFragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void categoryPressed (){
        Bundle bundle = new Bundle();
        bundle.putString("category", categoryRecommended02);

        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        Fragment itemSearchedFragment = new ItemsSearchedFragment();
        itemSearchedFragment.setArguments(bundle);
        fragmentTransaction.replace(R.id.fragment_container, itemSearchedFragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.itemImageRecommended:
                recommendedPressed(itemIdRecommended);
                break;
            case R.id.itemNameRecommended:
                recommendedPressed(itemIdRecommended);
                break;
            case R.id.itemCategoryRecommended:
                categoryPressed();
                break;
            case R.id.itemPriceRecommended:
                recommendedPressed(itemIdRecommended);
                break;
        }
    }

}
