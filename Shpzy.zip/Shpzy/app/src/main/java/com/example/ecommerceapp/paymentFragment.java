package com.example.ecommerceapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.HashMap;

public class paymentFragment extends Fragment{

    TextView totalTV;
    Button buyBtn;
    Button returnToHome;
    int balance;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_payment, container, false);
        Context contextFragment = getActivity();

        String email = HomeActivity.email;

        ItemDb db = new ItemDb(contextFragment);

        totalTV = (TextView) rootView.findViewById(R.id.totalTV);
        int total = db.GetTotalCart(email);

        if(total <=0){
            getActivity().getSupportFragmentManager().popBackStack();
        }

        totalTV.setText(String.valueOf(total));

        UserDb userDb = new UserDb(contextFragment);

        ArrayList<HashMap<String, String>> itemList = db.GetItemsInCart(email);
        ArrayList<HashMap<String,String>> userList = userDb.GetusersByid(email);

        ListView idListView = (ListView) rootView.findViewById(R.id.listItemsPayment);
        ListAdapter adapter = new SimpleAdapter(contextFragment, itemList, R.layout.payment_row, new String[]{"name","quantityincart","totalPriceItem"},new int[]{R.id.itemNamePayment,R.id.itemQuantityPayment,R.id.pricePayment});
        idListView.setAdapter(adapter);

        buyBtn = (Button) rootView.findViewById(R.id.payBtn);
        returnToHome = (Button) rootView.findViewById(R.id.returnHomeBtn);

        buyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                balance = Integer.parseInt(userList.get(0).get("balance"));
                if(balance>= total) {
                    String quantityOrdered = "0";
                    for(int i=0; i<itemList.size(); i++){
                        quantityOrdered = itemList.get(i).get("quantityincart");
                        int itemid = Integer.parseInt(itemList.get(i).get("itemid"));
                        db.UpdateItemQuantity(quantityOrdered,itemid);
                        balance -= total;
                        userDb.updateBalance(String.valueOf(balance), email);
                        db.DeleteItemCart(String.valueOf(itemid), email);

                        FragmentManager fragmentManager = getParentFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        Fragment selectedFragment = new OrderPlacedFragment();
                        fragmentTransaction.replace(R.id.fragment_container, selectedFragment);
                        fragmentTransaction.addToBackStack(null);
                        fragmentTransaction.commit();

                        //getActivity().getSupportFragmentManager().popBackStack();
                    }
                    userDb.incrementOrders(email);
                    Toast.makeText(contextFragment, "Your order has been successfully completed!", Toast.LENGTH_SHORT).show();
                } else Toast.makeText(contextFragment, "Not enough funds", Toast.LENGTH_SHORT).show();
            }
        });

        return rootView;
    }

}
