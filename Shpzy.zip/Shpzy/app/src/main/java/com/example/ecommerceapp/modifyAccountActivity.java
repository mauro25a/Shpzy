package com.example.ecommerceapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class modifyAccountActivity extends AppCompatActivity {

    TextView emailTextView;
    TextView passwordTextView;
    TextView nameTextView;
    TextView surnameTextView;
    TextView addressTextView;
    Button modifyBtn;
    String oldEmail;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_account);

        Intent intentLogin = getIntent();
        oldEmail = intentLogin.getStringExtra("email");

        emailTextView = (TextView) findViewById(R.id.emailModify);
        passwordTextView = (TextView) findViewById(R.id.passwordModify);
        nameTextView = (TextView) findViewById(R.id.nameModify);
        surnameTextView = (TextView) findViewById(R.id.surnameModify);
        addressTextView = (TextView) findViewById(R.id.addressModify);
        modifyBtn = (Button) findViewById(R.id.modifyBtn);

        modifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameTextView.getText().toString();
                String surname = surnameTextView.getText().toString();
                String email = emailTextView.getText().toString();
                String password = passwordTextView.getText().toString();
                String address = addressTextView.getText().toString();

                UserDb userDb = new UserDb(modifyAccountActivity.this);
                boolean isEmailValid = android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
                if(isEmailValid != true)
                    Toast.makeText(getApplicationContext(), "Please enter a valid email", Toast.LENGTH_SHORT).show();
                else if (password.equals("") || (name.equals("") || surname.equals("") || address.equals("")))
                    Toast.makeText(getApplicationContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show();
                else if(userDb.searchUser(emailTextView.getText().toString()))
                    Toast.makeText(getApplicationContext(), "This email is already used", Toast.LENGTH_SHORT).show();
                else {
                    userDb.Updateuserdetails(oldEmail, email, password, address, name, surname);
                    ItemDb itemDb = new ItemDb(getApplicationContext());
                    itemDb.updateCronologyAndCart(oldEmail, email);
                    Intent intent01 = new Intent(getApplicationContext(), HomeActivity.class);
                    intent01.putExtra("email", email);
                    startActivity(intent01);
                    finish();
                }
            }
        });

    }

}
