package com.example.ecommerceapp;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class SearchFragment extends Fragment{

    EditText searchET;
    String searchWord;
    ListView CronologyListView;

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_search, container, false);
        FragmentActivity context = getActivity();

        FragmentManager fragmentManager = getParentFragmentManager();

        UserDb userDb = new UserDb(context);
        ArrayList<HashMap<String,String>> cronology = userDb.GetCronology(HomeActivity.email);
        Collections.reverse(cronology);

        if(cronology.size()>=1){ //cronologia non vuota
            CronologyListView = (ListView) rootView.findViewById(R.id.listCronology);
            cronologyAdapter adapter = new cronologyAdapter(context, getParentFragmentManager(), cronology);
            CronologyListView.setAdapter(adapter);
        }

        searchET = (EditText) rootView.findViewById(R.id.search_edit_text);

        searchET.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(actionId == EditorInfo.IME_ACTION_SEARCH){
                    searchWord = String.valueOf(searchET.getText());

                    Bundle bundle = new Bundle();
                    bundle.putString("searchWord", searchWord);

                    FragmentManager fragmentManager = getParentFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    Fragment itemsSearched = new ItemsSearchedFragment();
                    itemsSearched.setArguments(bundle);
                    fragmentTransaction.replace(R.id.fragment_container, itemsSearched);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();

                    return true;
                }
                return false;
            }
        });

        return rootView;
    }

}
