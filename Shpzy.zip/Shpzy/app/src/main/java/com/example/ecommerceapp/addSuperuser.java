package com.example.ecommerceapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class addSuperuser extends AppCompatActivity {

    EditText emailET;
    EditText passwordET;
    Button createSuperuser;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_superuser);

        emailET = (EditText) findViewById(R.id.emailSuperuserAdd);
        passwordET = (EditText) findViewById(R.id.passwordSuperuserAdd);

        createSuperuser = (Button) findViewById(R.id.addSuperuserBtn02);

        createSuperuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailET.getText().toString();
                String password = passwordET.getText().toString();

                UserDb userDb = new UserDb(addSuperuser.this);
                boolean isEmailValid = android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
                if(isEmailValid != true)
                    Toast.makeText(getApplicationContext(), "Please enter a valid email", Toast.LENGTH_SHORT).show();
                else if (password.equals(""))
                    Toast.makeText(getApplicationContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show();
                else if(userDb.searchUser(emailET.getText().toString()) || userDb.searchSuperser(emailET.getText().toString()))
                    Toast.makeText(getApplicationContext(), "This email is already used", Toast.LENGTH_SHORT).show();
                else {
                    userDb.insertSuperuser(email,password);
                    Intent intent01 = new Intent(getApplicationContext(), UserList.class);
                    startActivity(intent01);
                    finish();
                }
            }
        });

    }

}
