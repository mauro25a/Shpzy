package com.example.ecommerceapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import java.util.ArrayList;
import java.util.HashMap;

public class MoreReviewsFragment extends Fragment implements AdapterView.OnItemSelectedListener{

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_more_reviews, container, false);
        Context contextFragment = getActivity();

        FragmentManager fragmentManager = getParentFragmentManager();

        String itemId = getArguments().getString("itemid");

        ListView reviewListView = (ListView) rootView.findViewById(R.id.reviewListView);

        UserDb reviewDb = new UserDb(contextFragment);
        ArrayList<HashMap<String, String>> reviewList = reviewDb.GetReviewByItem(itemId);
        ReviewsAdapter reviewsAdapter = new ReviewsAdapter(contextFragment, reviewList);
        reviewListView.setAdapter(reviewsAdapter);

        return rootView;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}