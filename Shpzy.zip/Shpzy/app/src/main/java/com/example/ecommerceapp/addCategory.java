package com.example.ecommerceapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class addCategory extends AppCompatActivity {

    Button addBtn;
    EditText categoryET;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_category_activity);

        addBtn = (Button) findViewById(R.id.addCategoryBtn02);
        categoryET = findViewById(R.id.categoryNewET);

        ItemDb itemDb = new ItemDb(getApplicationContext());

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String categoryNew = categoryET.getText().toString();
                if(categoryNew.equals(""))
                    Toast.makeText(addCategory.this, "Please enter a category", Toast.LENGTH_SHORT).show();
                else if(itemDb.checkCategoryIfExists(categoryNew)==true)
                    Toast.makeText(addCategory.this, "This category exists", Toast.LENGTH_SHORT).show();
                else {
                    itemDb.insertCategory(categoryNew);
                    Toast.makeText(addCategory.this, "Category inserted correctly", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
