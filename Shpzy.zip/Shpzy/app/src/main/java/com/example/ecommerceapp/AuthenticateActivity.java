package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class AuthenticateActivity extends AppCompatActivity {

    EditText emailTextView;
    EditText passwordTextView;
    TextView newToTextview;
    Button loginButton;
    Button signupButton;
    ImageView showPasswordIV;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authenticate);

        emailTextView = (EditText) findViewById(R.id.emailTextView);
        passwordTextView = (EditText) findViewById(R.id.passwordTextView);
        newToTextview = (TextView) findViewById(R.id.newToTextView);
        loginButton = (Button) findViewById(R.id.loginButton);
        signupButton = (Button) findViewById(R.id.signupButton);
        showPasswordIV = (ImageView) findViewById(R.id.showPasswordIV);

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent01 = new Intent(getApplicationContext(), CreateAccount.class);
                startActivity(intent01);
            }
        });

        showPasswordIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(passwordTextView.getTransformationMethod() == PasswordTransformationMethod.getInstance()){
                    passwordTextView.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else if(passwordTextView.getTransformationMethod() == HideReturnsTransformationMethod.getInstance()){
                    passwordTextView.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserDb db = new UserDb(getApplicationContext());
                String email = emailTextView.getText().toString();
                String password = passwordTextView.getText().toString();
                int i;
                if(db.searchUser(email, password)) {
                    Toast.makeText(AuthenticateActivity.this, "Log in successed", Toast.LENGTH_SHORT).show();
                    Intent intent01 = new Intent(getApplicationContext(), HomeActivity.class);
                    intent01.putExtra("email", email);
                    startActivity(intent01);
                    finish();
                } else if(db.authSuperuser(email, password)){
                    Intent intent01 = new Intent(getApplicationContext(), SuperuserHome.class);
                    Toast.makeText(AuthenticateActivity.this, "Log in successed", Toast.LENGTH_SHORT).show();
                    intent01.putExtra("email", email);
                    startActivity(intent01);
                    finish();
                } else Toast.makeText(AuthenticateActivity.this, "Email or password are not correct", Toast.LENGTH_SHORT).show();
            }
        });
    }


}
