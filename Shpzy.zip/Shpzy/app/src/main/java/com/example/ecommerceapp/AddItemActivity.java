package com.example.ecommerceapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.Random;

public class AddItemActivity extends AppCompatActivity {

    Button addItemBtn;
    EditText ETname;
    EditText ETdetails;
    EditText ETquantity;
    EditText ETprice;
    Spinner SpinnerCategory;
    ImageView IVimageitem;

    Random randomInt;
    Button randomPickerBtn;
    Boolean imageChosen;

    Integer[] images = {
            R.drawable.image_01,
            R.drawable.image_02,
            R.drawable.image_03,
            R.drawable.image_04,
            R.drawable.image_05,
            R.drawable.image_06,
            R.drawable.image_07,
            R.drawable.image_08,
            R.drawable.image_09
    };



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        addItemBtn = (Button) findViewById(R.id.add_item_button);
        ETname = (EditText) findViewById(R.id.item_name_edit);
        ETdetails = (EditText) findViewById(R.id.item_details_edit);
        ETquantity = (EditText) findViewById(R.id.item_quantity_edit);
        ETprice = (EditText) findViewById(R.id.item_price_edit);
        SpinnerCategory = (Spinner) findViewById(R.id.item_category_spinner);
        IVimageitem = (ImageView) findViewById(R.id.image_item);

        Spinner mySpinner = (Spinner) findViewById(R.id.item_category_spinner);
        ArrayAdapter<String> adapter;

        List<String> list;

        ItemDb db = new ItemDb(getApplicationContext());
        list = db.GetCategories();

        adapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(adapter);

        imageChosen = false;
        randomPickerBtn = (Button) findViewById(R.id.random_picker_btn);
        randomInt = new Random();

        randomPickerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = randomInt.nextInt(images.length);
                IVimageitem.setImageResource(images[i]);
                IVimageitem.setId(images[i]);
                imageChosen = true;
            }
        });

        addItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = String.valueOf(ETname.getText());
                String details = String.valueOf(ETdetails.getText());
                String category = String.valueOf(SpinnerCategory.getSelectedItem());
                String priceStr = String.valueOf(ETprice.getText());
                String quantityStr = String.valueOf(ETquantity.getText());
                String imageid = String.valueOf(IVimageitem.getId());

                if(name.equals("") || details.equals("") || category.equals("") || priceStr.equals("") || quantityStr.equals("") || imageChosen==false){
                    Toast.makeText(AddItemActivity.this, "Please insert all infos for the item", Toast.LENGTH_SHORT).show();
                } else {
                    ItemDb db = new ItemDb(AddItemActivity.this);
                    db.insertItemDetails(name, priceStr, category, quantityStr, details, imageid);
                    Intent goToItemList = new Intent(getApplicationContext(), ItemList.class);
                    startActivity(goToItemList);
                    finish();
                }

            }
        });


    }
}
