package com.example.ecommerceapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SuperuserHome extends AppCompatActivity {

    Button userListButton;
    Button itemButton;
    Button addCategory;
    TextView usersNumber;
    TextView itemsNumber;
    TextView reviewsNumbers;
    TextView emailSuperuser;
    static String email;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_superuser_home);

        userListButton = (Button) findViewById(R.id.user_list_btn);
        itemButton = (Button) findViewById(R.id.item_list_btn);

        usersNumber = (TextView) findViewById(R.id.usersNumber);
        itemsNumber = (TextView) findViewById(R.id.itemsNumber);
        reviewsNumbers = (TextView) findViewById(R.id.reviewsNumber);
        emailSuperuser = (TextView) findViewById(R.id.emailSuperuser);

        Intent intentLogin = getIntent();
        String superUserEmail = intentLogin.getStringExtra("email");

        emailSuperuser.setText(superUserEmail);

        UserDb userDb = new UserDb(getApplicationContext());
        if(Integer.parseInt(userDb.GetUsersCount())==0)
            usersNumber.setText("0");
        else usersNumber.setText(userDb.GetUsersCount());
        if(Integer.parseInt(userDb.GetReviewsNumber())==0)
            reviewsNumbers.setText("0");
        else reviewsNumbers.setText(userDb.GetReviewsNumber());

        ItemDb itemDb = new ItemDb(getApplicationContext());
        if(Integer.parseInt(itemDb.GetNumberItems())==0)
            itemsNumber.setText("0");
        else itemsNumber.setText(itemDb.GetNumberItems());

        addCategory = (Button) findViewById(R.id.addCategoryBtn);

        addCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCategory = new Intent(getApplicationContext(), addCategory.class);
                startActivity(intentCategory);
            }
        });

        userListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentUserList = new Intent(getApplicationContext(), UserList.class);
                intentUserList.putExtra("email", superUserEmail);
                startActivity(intentUserList);
            }
        });

        itemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentItemList = new Intent(getApplicationContext(),ItemList.class);
                startActivity(intentItemList);
            }
        });

    }

}
