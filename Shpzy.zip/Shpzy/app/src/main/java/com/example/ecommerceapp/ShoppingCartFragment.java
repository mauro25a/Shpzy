package com.example.ecommerceapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.HashMap;

public class ShoppingCartFragment extends Fragment{
    Button buyItemsBtn;
    int totalInCart = 0;
    ArrayList<HashMap<String, String>> itemList;
    Button invisibleSearchBtn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_shopping_cart, container, false);
        Context contextFragment = getActivity();

        buyItemsBtn = rootView.findViewById(R.id.buyItemsBtn);

        ItemDb db = new ItemDb(contextFragment);
        String email = HomeActivity.email;
        ArrayList<Integer> itemsId = db.GetItemsIdInCart(email);
        itemList = db.GetItemsInCart(email);
        ListView lv = (ListView) rootView.findViewById(R.id.shoppingCartList);

        if(itemList.size() == 0){
            ConstraintLayout constraintLayout = rootView.findViewById(R.id.constraintLayoutCart);
            constraintLayout.removeView(lv);

            //elimino buyItemsBtn
            constraintLayout.removeView(buyItemsBtn);

            //creo l'immagine del carrello vuoto
            ImageView emptyCartIV = new ImageView(contextFragment);
            emptyCartIV.setImageResource(R.drawable.empty_cart02);
            emptyCartIV.setId(View.generateViewId()); //per aggiungere l'image view al constraint layout bisogna settare l'id di tutte le view che contiene

            constraintLayout.addView(emptyCartIV);

            ConstraintSet constraintSet = new ConstraintSet();

            //setto i constraint
            constraintSet.connect(emptyCartIV.getId(), ConstraintSet.TOP, constraintLayout.getId(), ConstraintSet.TOP, 0);
            constraintSet.connect(emptyCartIV.getId(), ConstraintSet.BOTTOM, constraintLayout.getId(), ConstraintSet.BOTTOM, 0);
            constraintSet.connect(emptyCartIV.getId(), ConstraintSet.START, constraintLayout.getId(), ConstraintSet.START, 80);
            constraintSet.connect(emptyCartIV.getId(), ConstraintSet.END, constraintLayout.getId(), ConstraintSet.END, 80);

            constraintSet.applyTo(constraintLayout);
        }
        else {
            cartAdapter adapter = new cartAdapter(contextFragment, getParentFragmentManager(), itemList, email);
            lv.setAdapter(adapter);
        }

        buyItemsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemList = db.GetItemsInCart(email);
                totalInCart = 0;
                for(int i=0; i<itemList.size(); i++){
                    totalInCart += Integer.parseInt(itemList.get(i).get("price")) * Integer.parseInt(itemList.get(i).get("quantityincart"));
                }

                Bundle bundle = new Bundle();
                bundle.putIntegerArrayList("itemsInCart", itemsId);
                bundle.putInt("totalPrice", totalInCart);

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment selectedFragment = new paymentFragment();
                selectedFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, selectedFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) { //view è la view che è stata cliccata nella listview lv
                int itemIdClicked = itemsId.get(position);

                Bundle bundle = new Bundle();
                bundle.putString("itemid", String.valueOf(itemIdClicked));

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment selectedFragment = new ItemPageFragment();
                selectedFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, selectedFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });

        invisibleSearchBtn = (Button) rootView.findViewById(R.id.button_search);

        invisibleSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment selectedFragment = null;

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment searchFragment = new SearchFragment();
                fragmentTransaction.replace(R.id.fragment_container, searchFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });

        return rootView;
    }

}
