package com.example.ecommerceapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.HashMap;

public class HomeActivity extends AppCompatActivity{

    static String email;
    static String categoryRecommended = "";
    static ArrayList<HashMap<String, String>> cronologyWords = new ArrayList<>();
    static ArrayList<HashMap<String,String>> categoryList;

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    switch(item.getItemId()){
                        case R.id.nav_home:
                            Fragment homeFragment = new HomeFragment();
                            fragmentTransaction.replace(R.id.fragment_container, homeFragment);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();
                            break;
                        case R.id.nav_account:
                            Fragment accountFragment = new AccountFragment();
                            fragmentTransaction.replace(R.id.fragment_container, accountFragment);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();
                            break;
                        case R.id.nav_shopping_cart:
                            Fragment shoppingCartFragment = new ShoppingCartFragment();
                            fragmentTransaction.replace(R.id.fragment_container, shoppingCartFragment);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();
                            break;
                    }

                    return true;
                }
            };
    private boolean doubleBackToExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        categoryList = new ArrayList<>();
        HashMap<String,String> category = new HashMap<>();
        category.put("category", "Clothing");
        category.put("category", "Technology");
        category.put("category", "Food");
        category.put("category", "Accessories");
        category.put("category", "Sport");
        category.put("category", "Gardering");

        Intent intentLogin = getIntent();
        email = intentLogin.getStringExtra("email");

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        Fragment homeFragment = new HomeFragment();
        fragmentTransaction.replace(R.id.fragment_container, homeFragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();


    }

    @Override
    public void onBackPressed() {
        FragmentManager fragmentManager = getSupportFragmentManager();


         if (fragmentManager.getBackStackEntryCount() > 1) {
            fragmentManager.popBackStack();
        } else {
            exitApp();
        }

    }

    private void exitApp() {
        if (doubleBackToExitPressedOnce) {
            finish();
            System.exit(0);
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Premi indietro di nuovo per chiudere l'app", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000); // Delay di 2 secondi
    }

}