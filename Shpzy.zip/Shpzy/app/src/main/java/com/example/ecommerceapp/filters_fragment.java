package com.example.ecommerceapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.List;

public class filters_fragment extends Fragment{

    String searchWord = "";
    String category = "";
    String filter = "";
    String order = "No order";
    Spinner categorySpinner;
    Button searchBtn;
    EditText searchWordET;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.filters_fragment, container, false);
        FragmentActivity context = getActivity();

        searchWordET = (EditText) rootView.findViewById(R.id.searchWordFilter);

        if (getArguments().containsKey("searchWord")) {
            searchWord = getArguments().getString("searchWord");
            searchWordET.setText(searchWord);
        }

        if (getArguments().containsKey("category")) {
            category = getArguments().getString("category");
        }

        if (getArguments().containsKey("filter")) {
            filter = getArguments().getString("filter");
        }

        if (getArguments().containsKey("order")) {
            order = getArguments().getString("order");
        }

        categorySpinner = (Spinner) rootView.findViewById(R.id.spinnerCategory03);
        ArrayAdapter<String> categoryAdapter;

        List<String> categoryList;

        ItemDb db = new ItemDb(context);

        categoryList = new ArrayList<>();
        categoryList.add("No category");

        List<String> tempCategoryList = db.GetCategories();
        for(int i=0; i<tempCategoryList.size(); i++){
            categoryList.add(tempCategoryList.get(i));
        }

        categoryAdapter = new ArrayAdapter<String>(context,
                android.R.layout.simple_spinner_item, categoryList);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        ////

        Spinner filterSpinner = (Spinner) rootView.findViewById(R.id.filterSpinner);
        ArrayAdapter<String> adapter;

        List<String> list;

        list = new ArrayList<String>();
        list.add("No filters");
        list.add("Price: ascendent order");
        list.add("Price: descendent order");
        list.add("Rating: ascendent order");
        list.add("Rating: descendent order");

        adapter = new ArrayAdapter<String>(context,
                android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        filterSpinner.setAdapter(adapter);

        searchBtn = (Button) rootView.findViewById(R.id.searchButtonFilters);

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String categorySelected = categorySpinner.getSelectedItem().toString();
                String filterSelected = filterSpinner.getSelectedItem().toString();

                if(categorySelected.equals("No category"))
                    category = "";
                else category = categorySelected;

                if(filterSelected.equals("No filter"))
                    filter = "";
                else if(filterSelected.equals("Price: ascendent order")){
                    filter = "Price";
                    order = "ASC";
                } else if(filterSelected.equals("Price: descendent order")){
                    filter = "Price";
                    order = "DESC";
                } else if(filterSelected.equals("Rating: ascendent order")){
                    filter = "Rating";
                    order = "ASC";
                } else if(filterSelected.equals("Rating: descendent order")) {
                    filter = "Rating";
                    order = "DESC";
                }

                searchWord = String.valueOf(searchWordET.getText());

                Bundle bundle = new Bundle();
                bundle.putString("searchWord", searchWord);
                bundle.putString("category", category);
                bundle.putString("filter", filter);
                bundle.putString("order", order);

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment selectedFragment = new ItemsSearchedFragment();
                selectedFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, selectedFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return rootView;
    }

}

