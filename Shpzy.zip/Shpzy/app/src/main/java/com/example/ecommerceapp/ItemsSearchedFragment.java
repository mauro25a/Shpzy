package com.example.ecommerceapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public class ItemsSearchedFragment extends Fragment {

    String searchWord = "";
    String category = "";
    String filter = "";
    String order = "No order";
    List<HashMap<String, String>> itemList = new ArrayList<>();
    Button filterButton;
    Button invisibleSearchBtn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_item_searched, container, false);
        FragmentActivity context = getActivity();

        FragmentManager fragmentManager = getParentFragmentManager();


        if (getArguments().containsKey("searchWord")) {
            searchWord = getArguments().getString("searchWord");
        }

        if (getArguments().containsKey("category")) {
            category = getArguments().getString("category");
        }

        if (getArguments().containsKey("filter")) {
            filter = getArguments().getString("filter");
        }

        if (getArguments().containsKey("order")) {
            order = getArguments().getString("order");
        }

        //aggiungo il termine cercato ad un arraylist della cronologia
        if (HomeActivity.cronologyWords.contains(searchWord)) {
            HomeActivity.cronologyWords.remove(searchWord);
        }
        Collections.reverse(HomeActivity.cronologyWords);

        UserDb userDb = new UserDb(context);
        userDb.deleteCronology(HomeActivity.email, searchWord); //cancello la searchword se già esiste
        userDb.addCronologyWord(HomeActivity.email, searchWord);

        ItemDb itemDb = new ItemDb(context);

        ListView listView = rootView.findViewById(R.id.item_list_searched);

            String SELECT = "SELECT * FROM itemdetails ";
            String where = "WHERE LOWER(name) LIKE '%" + searchWord.toLowerCase() + "%' ";
            String whereCategory = "AND category ='" + category + "'";
            String filterquery = " ORDER BY " + filter;
            String orderquery = " " + order;

            String query = SELECT + where;
            if(!category.equals(""))
                query += whereCategory;
            if(!filter.equals("") && !filter.equals("No filter") && !filter.equals("Rating")) {
                query += filterquery;
                if (!order.equals("") && !order.equals("No order"))
                    query += orderquery;
            }
            itemList = itemDb.GetItemsByQuery(query);

            if(itemList.size() == 0){
                ConstraintLayout constraintLayout = rootView.findViewById(R.id.constraintLayoutItemsSearched);
                constraintLayout.removeView(listView);

                View divider16 = rootView.findViewById(R.id.divider16);

                //creo l'immagine della ricerca fallita
                ImageView noResultsIV = new ImageView(context);
                noResultsIV.setImageResource(R.drawable.no_result);
                noResultsIV.setId(View.generateViewId()); //per aggiungere l'image view al constraint layout bisogna settare l'id di tutte le view che contiene

                constraintLayout.addView(noResultsIV);

                ConstraintSet constraintSet = new ConstraintSet();

                //setto i constraint
                constraintSet.connect(noResultsIV.getId(), ConstraintSet.TOP, divider16.getId(), ConstraintSet.TOP, 0);
                constraintSet.connect(noResultsIV.getId(), ConstraintSet.BOTTOM, constraintLayout.getId(), ConstraintSet.BOTTOM, 0);
                constraintSet.connect(noResultsIV.getId(), ConstraintSet.START, constraintLayout.getId(), ConstraintSet.START, 80);
                constraintSet.connect(noResultsIV.getId(), ConstraintSet.END, constraintLayout.getId(), ConstraintSet.END, 80);

                constraintSet.applyTo(constraintLayout);
            }

            if(filter.equals("Rating")){
                Comparator<HashMap<String, String>> distanceComparator = new Comparator<HashMap<String,String>>() {

                    @Override
                    public int compare(HashMap<String, String> o1, HashMap<String, String> o2) {
                        float ratingAvg1 = Float.parseFloat(o1.get("rating_avg"));
                        float ratingAvg2 = Float.parseFloat(o2.get("rating_avg"));

                        if(order.equals("ASC")) { //ordine ascendente
                            if (ratingAvg1 < ratingAvg2) {
                                return -1;
                            } else if (ratingAvg1 > ratingAvg2) {
                                return 1;
                            } else {
                                return 0;
                            }
                        } else if(order.equals("ASC")){ //ordine decrescente
                            if (ratingAvg1 < ratingAvg2) {
                                return 1;
                            } else if (ratingAvg1 > ratingAvg2) {
                                return -1;
                            } else {
                                return 0;
                            }
                        }
                        return 0;
                    }
                };
                Collections.sort(itemList, distanceComparator);

            }

        // Aggiungi gli elementi alla lista
        itemSearchedAdapter itemAdapter = new itemSearchedAdapter(context, itemList);
        listView.setAdapter(itemAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Fragment fragment = new Fragment();

                Bundle bundle = new Bundle();
                bundle.putString("itemid", itemList.get(position).get("itemid"));

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment selectedFragment = new ItemPageFragment();
                selectedFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, selectedFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        filterButton = (Button) rootView.findViewById(R.id.filterButton);

        filterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("searchWord", searchWord);
                bundle.putString("category", category);
                bundle.putString("filter", filter);
                bundle.putString("order", order);

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment itemsSearched = new filters_fragment();
                itemsSearched.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, itemsSearched);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        invisibleSearchBtn = (Button) rootView.findViewById(R.id.button_search);

        invisibleSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment selectedFragment = null;

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment searchFragment = new SearchFragment();
                fragmentTransaction.replace(R.id.fragment_container, searchFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });

        return rootView;
    }

}