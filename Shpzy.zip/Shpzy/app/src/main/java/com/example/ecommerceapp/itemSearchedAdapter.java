package com.example.ecommerceapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

public class itemSearchedAdapter extends BaseAdapter {

    private Context context;
    private List<HashMap<String, String>> list;

    public itemSearchedAdapter(Context context, List<HashMap<String, String>> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_searched_row, parent, false);
        }

        TextView itemName = (TextView) convertView.findViewById(R.id.ItemNameTV);
        TextView  itemPrice = (TextView) convertView.findViewById(R.id.ItemPriceTV);
        TextView itemDetails = (TextView) convertView.findViewById(R.id.ItemDetailsTV02);
        ImageView itemImage = (ImageView) convertView.findViewById(R.id.itemImageTV);

        HashMap<String, String> item = list.get(position);
        itemName.setText(item.get("name"));
        itemPrice.setText(item.get("price"));
        itemDetails.setText(item.get("details"));
        itemImage.setImageResource(Integer.parseInt(item.get("image_id")));

        String itemid = item.get("id");

        return convertView;
    }
}