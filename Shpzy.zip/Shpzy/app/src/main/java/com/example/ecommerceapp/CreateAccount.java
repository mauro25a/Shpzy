package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CreateAccount extends AppCompatActivity {

    TextView emailTextView;
    TextView passwordTextView;
    TextView nameTextView;
    TextView surnameTextView;
    TextView addressTextView;
    Button createButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.insert_user_details);

        emailTextView = (TextView) findViewById(R.id.emailAddET);
        passwordTextView = (TextView) findViewById(R.id.passwordAddET);
        nameTextView = (TextView) findViewById(R.id.nameAddET);
        surnameTextView = (TextView) findViewById(R.id.surnameAddET);
        addressTextView = (TextView) findViewById(R.id.addressAddET);
        createButton = (Button) findViewById(R.id.createAccountBtn);

        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameTextView.getText().toString();
                String surname = surnameTextView.getText().toString();
                String email = emailTextView.getText().toString();
                String password = passwordTextView.getText().toString();
                String address = addressTextView.getText().toString();

                UserDb userDb = new UserDb(CreateAccount.this);
                boolean isEmailValid = android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
                if(isEmailValid != true)
                    Toast.makeText(getApplicationContext(), "Please enter a valid email", Toast.LENGTH_SHORT).show();
                else if (password.equals("") || (name.equals("") || surname.equals("") || address.equals("")))
                    Toast.makeText(getApplicationContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show();
                else if(userDb.searchUser(emailTextView.getText().toString()) || userDb.searchSuperser(emailTextView.getText().toString()))
                    Toast.makeText(getApplicationContext(), "This email is already used", Toast.LENGTH_SHORT).show();
                else {
                    userDb.insertuserdetails(email, password, "0".toString(), "100".toString(), address, name, surname);
                    Intent intent01 = new Intent(getApplicationContext(), HomeActivity.class);
                    intent01.putExtra("email", email);
                    startActivity(intent01);
                    finish();
                }
            }
        });



    }

}