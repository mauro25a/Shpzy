package com.example.ecommerceapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ItemDb extends SQLiteOpenHelper {
        private static final int DB_VERSION = 1;
        private static final String DB_NAME = "itemstable";
        private static final String TABLE_Items = "itemdetails";
        private static final String KEY_ID = "id";
        private static final String KEY_DETAILS = "details";
        private static final String KEY_NAME = "name";
        private static final String KEY_PRICE = "price";
        private static final String KEY_CATEGORY = "category";
        private static final String KEY_QUANTITY = "quantity";
        private static final String KEY_IMAGE_ID = "image_id";


        //Attributes of categories table
        private static final String TABLE_CATEGORY = "categorytable";
        private static final String CATEGORY_ID = "id";
        private static final String CATEGORY_NAME = "category";


        //attributes of the Shopping cart table
        private static final String TABLE_NAME_Cart = "tablecart";
        private static final String KEY_ID_CART = "id";
        private static final String KEY_USER_ID = "userid"; //La key di un utente è l'email
        private static final String KEY_ID_ITEM = "itemid";
        private static final String KEY_QUANTITY_IN_CART = "quantityincart";

        //attributes of the cronology table
        private static final String TABLE_CRONOLOGY = "cronologytable";
        private static final String ID_CRONOLOGY= "id";
        private static final String USER_ID_CRONOLOGY = "userid"; //La key di un utente è l'email
        private static final String ID_ITEM_CRONOLOGY = "itemid";
        private static final String TIMESTAMP = "time";

    Context context;

        public ItemDb(Context context) {
                super (context, DB_NAME, null, DB_VERSION);
                this.context = context;
        }
@Override
public void onCreate (SQLiteDatabase db){
        String CREATE_TABLE = "CREATE TABLE " + TABLE_Items + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_NAME + " TEXT, "
                + KEY_DETAILS + " TEXT, "
                + KEY_PRICE + " INTEGER, "
                + KEY_QUANTITY + " TEXT, "
                + KEY_CATEGORY + " TEXT, "
                + KEY_IMAGE_ID + " TEXT );";
    db.execSQL (CREATE_TABLE);

        String CREATE_CART_TABLE = "CREATE TABLE " + TABLE_NAME_Cart + "("
                + KEY_ID_CART + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_ID_ITEM + " TEXT, "
                + KEY_USER_ID + " TEXT, "
                + KEY_QUANTITY_IN_CART + " INTEGER);";
    db.execSQL (CREATE_CART_TABLE);

    String CREATE_CRONOLOGY = "CREATE TABLE " + TABLE_CRONOLOGY + "("
            + ID_CRONOLOGY + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + USER_ID_CRONOLOGY + " TEXT, "
            + TIMESTAMP + " TEXT, "
            + ID_ITEM_CRONOLOGY + " TEXT);";
    db.execSQL (CREATE_CRONOLOGY);

    String CREATE_CATEGORY_TABLE = "CREATE TABLE " + TABLE_CATEGORY + "("
            + CATEGORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + CATEGORY_NAME + " TEXT);";
    db.execSQL (CREATE_CATEGORY_TABLE);

    Integer[] images = {
            R.drawable.image_01,
            R.drawable.image_02,
            R.drawable.image_03,
            R.drawable.image_04,
            R.drawable.image_05,
            R.drawable.image_06,
            R.drawable.image_07,
            R.drawable.image_08,
            R.drawable.image_09
    };

    int DIM = images.length;
    String[] imagesId = new String[DIM];

    for(int i=0; i< DIM; i++) {
        imagesId[i] = String.valueOf(images[i]);
    }

    //creo alcuni articoli di default
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Dress', 'Vestito in cotone', '20', '10', 'Clothing', '" + imagesId[5] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Borsello', 'Nero, capiente', '30', '13', 'Accessories', '" + imagesId[0] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('MSI pc gaming', 'Nvidia RTX 3070', '900', '4', 'Technology', '" + imagesId[4] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Patè di melanzane Tigullio', '125 g, melanzane, olio di oliva, basilico', '3', '30', 'Food', '" + imagesId[3] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Crema viso', '10 g, idratante', '23', '7', 'Accessories', '" + imagesId[2] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Watch', 'Cinturino in pelle, finiture in metallo', '250', '28', 'Accessories', '" + imagesId[1] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Cover smartphone iPhone 13', 'trasparente, in silicone', '23', '3', 'Technology', '" + imagesId[7] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Casco', 'Rosso e nero', '115', '10', 'Sport', '" + imagesId[6] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('T-shirt', 'Maglietta blu, cotone', '12', '35', 'Clothing', '" + imagesId[8] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Dress', 'Vestito in lana', '25', '17', 'Clothing', '" + imagesId[5] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Borsello Richwest', 'Nero, capiente', '75', '12', 'Accessories', '" + imagesId[0] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('HP pc gaming', 'Nvidia RTX 3080', '100', '12', 'Technology', '" + imagesId[4] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Patè di melanzane Barilla', '150 g, melanzane, olio di oliva, basilico', '4', '35', 'Food', '" + imagesId[3] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Crema viso Nivea', '13 g, idratante', '12', '8', 'Accessories', '" + imagesId[2] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Watch Casio', 'Cinturino in pelle, finiture in metallo', '120', '22', 'Accessories', '" + imagesId[1] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Cover smartphone Xiami Redmi Note 8', 'trasparente, in silicone', '10', '8', 'Technology', '" + imagesId[7] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('Casco Alpinestar', 'Rosso e nero', '180', '5', 'Sport', '" + imagesId[6] + "')");
    db.execSQL("INSERT INTO " + TABLE_Items + " (name, details, price, quantity, category, image_id) VALUES ('T-shirt Nike', 'Maglietta blu, cotone', '18', '22', 'Clothing', '" + imagesId[8] + "')");

    //creo le categorie di default
    db.execSQL("INSERT INTO " + TABLE_CATEGORY + " (category) VALUES ('Clothing')");
    db.execSQL("INSERT INTO " + TABLE_CATEGORY + " (category) VALUES ('Technology')");
    db.execSQL("INSERT INTO " + TABLE_CATEGORY + " (category) VALUES ('Food')");
    db.execSQL("INSERT INTO " + TABLE_CATEGORY + " (category) VALUES ('Accessories')");
    db.execSQL("INSERT INTO " + TABLE_CATEGORY + " (category) VALUES ('Sport')");
    db.execSQL("INSERT INTO " + TABLE_CATEGORY + " (category) VALUES ('Gardering')");
}

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
                //Rimuove vecchie tabelle se esistono
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_Items);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_Cart);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_CRONOLOGY);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORY);
                //Crea una nuova tabella
                onCreate(db);
        }

        void insertItemDetails(String name, String price, String category, String quantity, String details, String imageid){
                //si accede al Data Repository in modalità scrittura
                SQLiteDatabase db = this.getWritableDatabase();
                //crea una nuova mappa di valori, dove il nome delle colonne sono le chiavi
                ContentValues cValues = new ContentValues();
                cValues.put(KEY_NAME, name);
                cValues.put(KEY_DETAILS, details);
                cValues.put(KEY_CATEGORY, category);
                cValues.put(KEY_PRICE, price);
                cValues.put(KEY_QUANTITY, quantity);
                cValues.put(KEY_IMAGE_ID, imageid);

                db.close();
        }

        void insertCronology(String itemid, String userid){
            //si accede al Data Repository in modalità scrittura
            SQLiteDatabase db = this.getWritableDatabase();
            if(checkIfExist(itemid, userid))
                updateCronology(itemid, userid, System.currentTimeMillis());
            else {
                //crea una nuova mappa di valori, dove il nome delle colonne sono le chiavi
                ContentValues cValues = new ContentValues();
                cValues.put(USER_ID_CRONOLOGY, userid);
                cValues.put(ID_ITEM_CRONOLOGY, itemid);
                cValues.put(TIMESTAMP, System.currentTimeMillis());
                //inserisci una nuova riga, restituendo il valore di primary key della nuova riga
                long newRowId = db.insert(TABLE_CRONOLOGY, null, cValues);
                db.close();
            }
        }

    void insertCategory(String newCategory){
        //si accede al Data Repository in modalità scrittura
        SQLiteDatabase db = this.getWritableDatabase();
        //crea una nuova mappa di valori, dove il nome delle colonne sono le chiavi
        ContentValues cValues = new ContentValues();
        cValues.put(CATEGORY_NAME, newCategory);
        //inserisci una nuova riga, restituendo il valore di primary key della nuova riga
        long newRowId = db.insert(TABLE_CATEGORY, null, cValues);
        db.close();
    }

    private boolean checkIfExist(String itemid, String userid) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_CRONOLOGY  + " WHERE userid = '" + userid + "' AND itemid = '" + itemid + "'";
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()==true) {
            return true;
        }
        return false;
    }

    public boolean checkCategoryIfExists(String newCategory){
        SQLiteDatabase db = this.getWritableDatabase();
        //String query = "SELECT * FROM " + TABLE_CATEGORY  + " WHERE category = '" + newCategory + "'";
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CATEGORY + " WHERE LOWER(category) = LOWER(?)", new String[] { newCategory });
        if(cursor.moveToFirst()==true) {
            return true;
        }
        return false;
    }

    private void updateCronology(String itemid, String userid, long time){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cVals = new ContentValues();
        cVals.put(TIMESTAMP, time);
        db.update(TABLE_CRONOLOGY, cVals, ID_ITEM_CRONOLOGY + " =? AND " + USER_ID_CRONOLOGY + " =?", new String[]{String.valueOf(itemid), String.valueOf(userid)});
    }

    public void updateCronologyAndCart(String oldEmail, String newEmail){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cartVals = new ContentValues();
        cartVals.put(KEY_USER_ID, newEmail);
        db.update(TABLE_NAME_Cart, cartVals, "userid =?", new String[]{String.valueOf(oldEmail)});

        ContentValues cronologyVals = new ContentValues();
        cronologyVals.put(USER_ID_CRONOLOGY, newEmail);
        db.update(TABLE_CRONOLOGY, cronologyVals, "userid =?", new String[]{String.valueOf(oldEmail)});
    }

    public ArrayList<HashMap<String,String>> getCronologyUser(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_Items + " a INNER JOIN " + TABLE_CRONOLOGY  + " b ON a.id = b.itemid"  + " WHERE b.userid = '" + email + "'" + " ORDER BY " + TIMESTAMP + " DESC LIMIT 5";
        Cursor cursor = db.rawQuery(query, null);
        UserDb userDb = new UserDb(context);
        float ratingAvg;
        while(cursor.moveToNext()){
            HashMap<String,String> item = new HashMap<>();
            ratingAvg = userDb.getRatingAvg(cursor.getColumnIndex(ID_ITEM_CRONOLOGY));
            item.put("itemidcronology", cursor.getString(cursor.getColumnIndex(ID_ITEM_CRONOLOGY)));
            item.put("userid", cursor.getString(cursor.getColumnIndex(USER_ID_CRONOLOGY)));
            item.put("time", cursor.getString(cursor.getColumnIndex(TIMESTAMP)));
            item.put("itemid", cursor.getString(cursor.getColumnIndex(ID_ITEM_CRONOLOGY)));
            item.put("name", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("price", cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
            item.put("quantity", cursor.getString(cursor.getColumnIndex(KEY_QUANTITY)));
            item.put("category", cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)));
            item.put("details", cursor.getString(cursor.getColumnIndex(KEY_DETAILS)));
            item.put("image_id", cursor.getString(cursor.getColumnIndex(KEY_IMAGE_ID)));
            item.put("ratingAvg", String.valueOf(ratingAvg));
            itemList.add(item);
        }
        db.close();
        cursor.close();
        return itemList;
    }

    public String GetNumberItems(){
        int count = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_Items;
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()) count = cursor.getInt(0);
        else count = 0;
        cursor.close();
        db.close();
        return String.valueOf(count);
    }

    public String getNumberCategories(){
        int count = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_CATEGORY;
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()) count = cursor.getInt(0);
        else count = 0;
        cursor.close();
        db.close();
        return String.valueOf(count);
    }

        public ArrayList<HashMap<String,String>>GetItems(){
                SQLiteDatabase db = this.getWritableDatabase();
                ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
                UserDb userDb = new UserDb(context);
                String query = "SELECT * FROM " + TABLE_Items;
                Cursor cursor = db.rawQuery(query, null);
                while(cursor.moveToNext()){
                        HashMap<String,String> item = new HashMap<>();
                        float avg = userDb.getRatingAvg(cursor.getColumnIndex(KEY_ID));
                        item.put("rating_avg", String.valueOf(avg));
                        item.put("itemid", cursor.getString(cursor.getColumnIndex(KEY_ID)));
                        item.put("name", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
                        item.put("price", cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
                        item.put("quantity", cursor.getString(cursor.getColumnIndex(KEY_QUANTITY)));
                        item.put("category", cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)));
                        item.put("details", cursor.getString(cursor.getColumnIndex(KEY_DETAILS)));
                        item.put("image_id", cursor.getString(cursor.getColumnIndex(KEY_IMAGE_ID)));
                        itemList.add(item);
                }
                db.close();
                cursor.close();
                return itemList;
        }

    public ArrayList<HashMap<String,String>>GetItemsByQuery(String inputQuery){
        SQLiteDatabase db = this.getWritableDatabase();
        UserDb userDb = new UserDb(context);
        ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
        String query = inputQuery;
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            HashMap<String,String> item = new HashMap<>();
            float avg = userDb.getRatingAvg(cursor.getColumnIndex(KEY_ID));
            item.put("rating_avg", String.valueOf(avg));
            item.put("itemid", cursor.getString(cursor.getColumnIndex(KEY_ID)));
            item.put("name", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("price", cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
            item.put("quantity", cursor.getString(cursor.getColumnIndex(KEY_QUANTITY)));
            item.put("category", cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)));
            item.put("details", cursor.getString(cursor.getColumnIndex(KEY_DETAILS)));
            item.put("image_id", cursor.getString(cursor.getColumnIndex(KEY_IMAGE_ID)));
            itemList.add(item);
        }
        db.close();
        cursor.close();
        return itemList;
    }

    public List<String> GetCategories(){
        SQLiteDatabase db = this.getWritableDatabase();
        List<String> categoryList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_CATEGORY;
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            String categoryName = cursor.getString(cursor.getColumnIndex("category"));
            categoryList.add(categoryName);
        }
        db.close();
        cursor.close();
        return categoryList;
    }

    public ArrayList<HashMap<String,String>> GetCategories02(){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> categoryList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_CATEGORY;
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            String selectedCategory = cursor.getString(cursor.getColumnIndex(CATEGORY_NAME));
            if(categoryIsEmpty(selectedCategory) == false) {  //Permette di visualizzare solo le categorie che hanno articoli in vendita
                HashMap<String, String> item = new HashMap<>();
                item.put("category", selectedCategory);
                categoryList.add(item);
            }
        }
        db.close();
        cursor.close();
        return categoryList;
    }

    public ArrayList<HashMap<String,String>>GetRecommendedItems(String category){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_Items + " WHERE category LIKE '%" + category.toLowerCase() + "%'";;
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            HashMap<String,String> item = new HashMap<>();
            item.put("itemid", cursor.getString(cursor.getColumnIndex(KEY_ID)));
            item.put("name", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("price", cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
            item.put("quantity", cursor.getString(cursor.getColumnIndex(KEY_QUANTITY)));
            item.put("category", cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)));
            item.put("details", cursor.getString(cursor.getColumnIndex(KEY_DETAILS)));
            item.put("image_id", cursor.getString(cursor.getColumnIndex(KEY_IMAGE_ID)));
            itemList.add(item);
        }
        db.close();
        cursor.close();
        return itemList;
    }

    public ArrayList<HashMap<String,String>>GetNotRecommendedItems(String category){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_Items + " WHERE category != '" + category + "'";;
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            HashMap<String,String> item = new HashMap<>();
            item.put("itemid", cursor.getString(cursor.getColumnIndex(KEY_ID)));
            item.put("name", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("price", cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
            item.put("quantity", cursor.getString(cursor.getColumnIndex(KEY_QUANTITY)));
            item.put("category", cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)));
            item.put("details", cursor.getString(cursor.getColumnIndex(KEY_DETAILS)));
            item.put("image_id", cursor.getString(cursor.getColumnIndex(KEY_IMAGE_ID)));
            itemList.add(item);
        }
        db.close();
        cursor.close();
        return itemList;
    }

    public ArrayList<HashMap<String,String>>GetItemsByid(int itemid){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
        String query = "SELECT name, price, quantity, category, details, image_id FROM " + TABLE_Items;
        Cursor cursor = db.query(TABLE_Items, new String[]{KEY_NAME,KEY_QUANTITY, KEY_DETAILS, KEY_CATEGORY, KEY_PRICE, KEY_IMAGE_ID}, KEY_ID+"=?", new String[]{String.valueOf(itemid)},null,null,null, null);
        if(cursor.moveToNext()){
            HashMap<String,String> item = new HashMap<>();
            item.put("name", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("price", cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
            item.put("quantity", cursor.getString(cursor.getColumnIndex(KEY_QUANTITY)));
            item.put("category", cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)));
            item.put("details", cursor.getString(cursor.getColumnIndex(KEY_DETAILS)));
            item.put("image_id", cursor.getString(cursor.getColumnIndex(KEY_IMAGE_ID)));
            itemList.add(item);
        }
        return itemList;
    }

    public HashMap<String,String> getItemById(int itemid){
        SQLiteDatabase db = this.getWritableDatabase();
        HashMap<String,String> item = new HashMap<>();
        Cursor cursor = db.query(TABLE_Items, new String[]{KEY_NAME,KEY_QUANTITY, KEY_DETAILS, KEY_CATEGORY, KEY_PRICE, KEY_IMAGE_ID}, KEY_ID+"=?", new String[]{String.valueOf(itemid)},null,null,null, null);
        if(cursor.moveToNext()){
            item.put("name", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("price", cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
            item.put("quantity", cursor.getString(cursor.getColumnIndex(KEY_QUANTITY)));
            item.put("category", cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)));
            item.put("details", cursor.getString(cursor.getColumnIndex(KEY_DETAILS)));
            item.put("image_id", cursor.getString(cursor.getColumnIndex(KEY_IMAGE_ID)));
        }
        return item;
    }

    public int getImageById(int itemId){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT image_id FROM " + TABLE_Items + " WHERE id = " + itemId;
        Cursor cursor = db.rawQuery(query, null);
        int iditem = 0;
        if(cursor.moveToNext()){
            int idColumnIndex = cursor.getColumnIndex("image_id");
            iditem = cursor.getInt(idColumnIndex);
        }
        cursor.close();
        return iditem;
    }

    public String getNameById(int itemId){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT name FROM " + TABLE_Items + " WHERE id = " + itemId;
        Cursor cursor = db.rawQuery(query, null);
        String iditem = "";
        if(cursor.moveToNext()){
            int idColumnIndex = cursor.getColumnIndex("name");
            iditem = cursor.getString(idColumnIndex);
        }
        cursor.close();
        return iditem;
    }

    public ArrayList<HashMap<String,String>>GetItemsCategory(String category){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * from " + TABLE_Items + " where category =?", new String[]{category});
        if(cursor.moveToFirst()){
            do {
                HashMap<String,String> item = new HashMap<>();
                item.put("itemid", cursor.getString(cursor.getColumnIndex(KEY_ID)));
                item.put("name", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
                item.put("price", cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
                item.put("image_id", cursor.getString(cursor.getColumnIndex(KEY_IMAGE_ID)));
                itemList.add(item);
            } while(cursor.moveToNext());
        }
        return itemList;
    }

    public boolean categoryIsEmpty(String category){ //Permette di visualizzare solo le categorie che hanno articoli in vendita
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * from " + TABLE_Items + " where category =?", new String[]{category});
        if(cursor.getCount() == 0)
            return true;
        return false;
    }

    public String getCategoryById(int itemId){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT category FROM " + TABLE_Items + " WHERE id = " + itemId;
        Cursor cursor = db.rawQuery(query, null);
        String category = "";
        if(cursor.moveToNext()){
            int idColumnIndex = cursor.getColumnIndex("category");
            category = cursor.getString(idColumnIndex);
        }
        cursor.close();
        return category;
    }

    public String getDetailsById(int itemId){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT details FROM " + TABLE_Items + " WHERE id = " + itemId;
        Cursor cursor = db.rawQuery(query, null);
        String details = "";
        if(cursor.moveToNext()){
            int idColumnIndex = cursor.getColumnIndex("details");
            details = cursor.getString(idColumnIndex);
        }
        cursor.close();
        return details;
    }

    public int getPriceById(int itemId){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT price FROM " + TABLE_Items + " WHERE id = " + itemId;
        Cursor cursor = db.rawQuery(query, null);
        int price = 0;
        if(cursor.moveToNext()){
            int idColumnIndex = cursor.getColumnIndex("price");
            price = cursor.getInt(idColumnIndex);
        }
        cursor.close();
        return price;
    }

    public int getQuantityById(int itemId){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT quantity FROM " + TABLE_Items + " WHERE id = " + itemId;
        Cursor cursor = db.rawQuery(query, null);
        int quantity = 0;
        if(cursor.moveToNext()){
            int idColumnIndex = cursor.getColumnIndex("quantity");
            quantity = cursor.getInt(idColumnIndex);
        }
        cursor.close();
        return quantity;
    }

    public void DeleteItem(int itemid){
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete(TABLE_Items, KEY_ID + " = ?", new String[]{String.valueOf(itemid)});
            db.delete(TABLE_NAME_Cart, KEY_ID_ITEM + " = ?", new String[]{String.valueOf(itemid)});
            db.close();
    }

    public int UpdateItemDetails(String name, String price, String quantity, String category, String details, String image_id, String id){
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cVals = new ContentValues();
            cVals.put(KEY_QUANTITY, quantity);
            cVals.put(KEY_CATEGORY, category);
            cVals.put(KEY_NAME, name);
            cVals.put(KEY_PRICE, price);
            cVals.put(KEY_DETAILS, details);
            cVals.put(KEY_IMAGE_ID, image_id);
            int count = db.update(TABLE_Items, cVals, KEY_ID + " =?", new String[]{String.valueOf(id)});
            return count;
        }

    public void UpdateItemQuantity(String quantityOrdered, int itemId){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cVals = new ContentValues();
        String query = "SELECT quantity FROM " + TABLE_Items + " WHERE id = " + itemId;
        Cursor cursor = db.rawQuery(query, null);
        int quantityInStock = 0;
        if(cursor.moveToNext()){
            int idColumnIndex = cursor.getColumnIndex("quantity");
            quantityInStock = cursor.getInt(idColumnIndex);
        }
        if(Integer.parseInt(quantityOrdered)<quantityInStock){
            quantityInStock -= Integer.parseInt(quantityOrdered);
            cVals.put(KEY_QUANTITY, quantityInStock);
            int count = db.update(TABLE_Items, cVals, KEY_ID + " =?", new String[]{String.valueOf(itemId)});
        } else{
            this.DeleteItem(itemId);
        }
    }

    public void DeleteItemCart(String itemid, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME_Cart, KEY_ID_ITEM + " = ? AND " + KEY_USER_ID + " = ?", new String[]{itemid, email});
        db.close();
    }

    public boolean UpdateQuantityInCart(String itemId, String userId, String quantity){ //quantity has to be already incremented or decremented
            if( checkQuantity(itemId,Integer.parseInt(quantity))==false)
                return false;
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cVals = new ContentValues();
            cVals.put(KEY_QUANTITY_IN_CART, quantity);
            db.update(TABLE_NAME_Cart, cVals, "itemid =? AND userid =?", new String[]{String.valueOf(itemId), userId});
            return true;
    }

    boolean checkQuantity(String itemId, int quantityRequested){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT quantity FROM " + TABLE_Items + " WHERE id = " + itemId;
        Cursor cursor = db.rawQuery(query, null);
        int quantityInStock = 0;
        if(cursor.moveToNext()){
            int idColumnIndex = cursor.getColumnIndex("quantity");
            quantityInStock = cursor.getInt(idColumnIndex);
        }
        cursor.close();
        if(quantityRequested > quantityInStock)
            return false;
        return true;
    }

    public boolean insertItemInCart(String userEmail, String itemId, int quantity, int quantityInStock){
        //si accede al Data Repository in modalità scrittura
        SQLiteDatabase db = this.getWritableDatabase();
            if(isItemInCart(itemId, userEmail) == false)
                return false;
            else if(checkQuantity(itemId,quantity+1) == false){
                ContentValues cValues = new ContentValues();
                cValues.put(KEY_USER_ID, userEmail);
                cValues.put(KEY_ID_ITEM, itemId);
                cValues.put(KEY_QUANTITY_IN_CART, quantityInStock);
                long result = db.insert(TABLE_NAME_Cart,null, cValues);
                return true;
            }
        //crea una nuova mappa di valori, dove il nome delle colonne sono le chiavi
        ContentValues cValues = new ContentValues();
        cValues.put(KEY_USER_ID, userEmail);
        cValues.put(KEY_ID_ITEM, itemId);
        cValues.put(KEY_QUANTITY_IN_CART, quantity);
        //inserisci una nuova riga, restituendo il valore di primary key della nuova riga
        long result = db.insert(TABLE_NAME_Cart,null, cValues);
        db.close();
        return true;
    }

    public boolean isItemInCart(String itemid, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME_Cart + " WHERE userid = '" + email + "'" + " AND itemid = '" + itemid + "'";
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.getCount()>=1) {
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }

    //Join itemsTable and ShoppingCartTable
    public ArrayList<HashMap<String,String>>GetItemsInCart(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_Items + " a INNER JOIN " + TABLE_NAME_Cart  + " b ON a.id = b.itemid"  + " WHERE b.userid = '" + email + "'";
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            HashMap<String,String> item = new HashMap<>();
            int price = Integer.parseInt(cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
            int quantityRequested = Integer.parseInt(cursor.getString(cursor.getColumnIndex(KEY_QUANTITY_IN_CART)));
            int quantityinStock = Integer.parseInt(cursor.getString(cursor.getColumnIndex(KEY_QUANTITY)));
            if(quantityRequested>quantityinStock)
                quantityRequested = quantityinStock;
            int totalPriceItem = price*quantityRequested;
            item.put("totalPriceItem", String.valueOf(totalPriceItem));
            item.put("itemid", cursor.getString(cursor.getColumnIndex(KEY_ID_ITEM)));
            item.put("name", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("price", cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
            item.put("quantityincart", String.valueOf(quantityRequested));
            item.put("category", cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)));
            item.put("details", cursor.getString(cursor.getColumnIndex(KEY_DETAILS)));
            item.put("image_id", cursor.getString(cursor.getColumnIndex(KEY_IMAGE_ID)));
            itemList.add(item);
        }
        return itemList;
    }

    public int GetTotalCart(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> itemList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_Items + " a INNER JOIN " + TABLE_NAME_Cart  + " b ON a.id = b.itemid"  + " WHERE b.userid = '" + email + "'";
        Cursor cursor = db.rawQuery(query, null);
        int total = 0;
        HashMap<String,String> item = new HashMap<>();
        while(cursor.moveToNext()){
            int price = Integer.parseInt(cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
            int quantity = Integer.parseInt(cursor.getString(cursor.getColumnIndex(KEY_QUANTITY_IN_CART)));
            int totalPriceItem = price*quantity;
            total += totalPriceItem;
        }
        return total;
    }

    public ArrayList<Integer> GetItemsIdInCart(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<Integer> itemList = new ArrayList<Integer>();
        String query = "SELECT * FROM " + TABLE_Items + " a INNER JOIN " + TABLE_NAME_Cart  + " b ON a.id = b.itemid"  + " WHERE b.userid = '" + email + "'";
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
           int idItem = cursor.getInt(cursor.getColumnIndex(KEY_ID_ITEM));
           itemList.add(idItem);
        }
        cursor.close();
        db.close();
        return itemList;
    }

}