package com.example.ecommerceapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import java.util.ArrayList;
import java.util.HashMap;

public class cartAdapter extends BaseAdapter {
    private ArrayList<HashMap<String, String>> mData;
    private Context mContext;
    private String email;
    private FragmentManager fragmentManager;

    public cartAdapter(Context context, FragmentManager fragmentManager, ArrayList<HashMap<String, String>> data, String email) {
        super();
        mContext = context;
        mData = data;
        this.email = email;
        this.fragmentManager=fragmentManager;
    }
    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.cart_list_row, parent, false);

        ItemDb db = new ItemDb(mContext);
        String itemId = mData.get(position).get("itemid");
        String itemPrice = mData.get(position).get("price");
        String itemName = mData.get(position).get("name");
        String itemImage = mData.get(position).get("image_id");
        String itemQuantity = mData.get(position).get("quantityincart");

        TextView itemNameTV = (TextView) convertView.findViewById(R.id.ItemNameCart);
        TextView itemPriceTV = (TextView) convertView.findViewById(R.id.priceInCart);
        TextView itemQuantityTV = (TextView) convertView.findViewById(R.id.quantityCart);
        ImageView itemImageIV = (ImageView) convertView.findViewById(R.id.imageInCart);
        Button increaseBtn = (Button) convertView.findViewById(R.id.increaseBtn);

        itemNameTV.setText(itemName);
        itemPriceTV.setText(itemPrice);
        itemQuantityTV.setText(itemQuantity);
        itemImageIV.setImageResource(Integer.parseInt(itemImage));

        Button decreaseBtn = (Button) convertView.findViewById(R.id.decreaseBtn);
        increaseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(itemQuantityTV.getText().toString()) + 1;
                if( db.UpdateQuantityInCart(itemId, email, String.valueOf(quantity)) )
                    itemQuantityTV.setText(String.valueOf(quantity));
            }
        });
        decreaseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(itemQuantityTV.getText().toString());
                if(quantity>=1){
                    quantity--;
                    if(quantity == 0) {
                        db.DeleteItemCart(itemId, email);
                        Fragment selectedFragment = new ShoppingCartFragment();
                        fragmentManager.beginTransaction().replace(R.id.fragment_container,
                                selectedFragment).commit();
                    }
                    itemQuantityTV.setText(String.valueOf(quantity));
                    db.UpdateQuantityInCart(itemId, email, String.valueOf(quantity));
                }
            }
        });

        return convertView;
    }
}
