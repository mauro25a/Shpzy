package com.example.ecommerceapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class UserList extends AppCompatActivity {

    Button deleteUserBtn;
    Button addSuperuserBtn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        Intent intentLogin = getIntent();
        String superUserEmail = intentLogin.getStringExtra("email");

        UserDb db = new UserDb(this);
        ArrayList<HashMap<String, String>> userList = db.Getusers();
        ListView lv = (ListView) findViewById(R.id.user_list);

        ArrayList<HashMap<String, String>> superuserList = db.GetSuperusers();
        int sizeSuperuserList = superuserList.size();
        for(int i=0; i<sizeSuperuserList; i++){
            userList.add(superuserList.get(i));
        }

        ListAdapter adapter = new SimpleAdapter(UserList.this, userList, R.layout.user_list_row, new String[]{"email","password","balance","orders","address","username","usersurname"},new int[]{R.id.user_email,R.id.user_password,R.id.user_balance,R.id.user_orders,R.id.user_address,R.id.user_name,R.id.user_surname});
        lv.setAdapter(adapter);

        deleteUserBtn = (Button) findViewById(R.id.removeUserBtn);
        addSuperuserBtn = (Button) findViewById(R.id.addSuperuserBtn);

        deleteUserBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent01 = new Intent(getApplicationContext(), removeUserActivity.class);
                intent01.putExtra("email", superUserEmail);
                startActivity(intent01);
            }
        });

        addSuperuserBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent01 = new Intent(getApplicationContext(), addSuperuser.class);
                startActivity(intent01);
            }
        });

    }

}
