package com.example.ecommerceapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class ReviewFragment extends Fragment{

    Button shareReviewBtn;
    EditText reviewEditText;
    RatingBar ratingStars;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_review, container, false);
        Context contextFragment = getActivity();

        FragmentManager fragmentManager = getParentFragmentManager();

        shareReviewBtn = (Button) rootView.findViewById(R.id.shareReviewBtn);
        reviewEditText = (EditText) rootView.findViewById(R.id.reviewET);
        ratingStars = (RatingBar) rootView.findViewById(R.id.ratingBar);

        shareReviewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(String.valueOf(reviewEditText.getText()).equals("")){
                    Toast.makeText(contextFragment, "Please write a review", Toast.LENGTH_SHORT).show();
                    return;
                } else if (ratingStars.getRating() == 0) {
                    Toast.makeText(contextFragment, "Please set the rating stars", Toast.LENGTH_SHORT).show();
                    return;
                }
                String email = HomeActivity.email;
                String itemid = getArguments().getString("itemid");
                String reviewText = String.valueOf(reviewEditText.getText());
                float rating = ratingStars.getRating();
                UserDb reviewDb = new UserDb(contextFragment);
                reviewDb.insertReview(email, itemid, reviewText, rating);
                Toast.makeText(contextFragment, "Review added", Toast.LENGTH_SHORT).show();

                Bundle bundle = new Bundle();
                bundle.putString("itemid", itemid);

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment itemFragment = new ItemPageFragment();
                itemFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, itemFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });


        return rootView;
    }

}
