package com.example.ecommerceapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class removeUserActivity extends AppCompatActivity {

    Button deleteBtn;
    EditText emailDelete;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.remove_user_activity);

        deleteBtn = (Button) findViewById(R.id.deleteUserBtn);
        emailDelete = (EditText) findViewById(R.id.emailDelete);

        UserDb userDb = new UserDb(getApplicationContext());

        Intent intentLogin = getIntent();
        String superUserEmail = intentLogin.getStringExtra("email");

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(emailDelete.getText().equals(""))
                    Toast.makeText(removeUserActivity.this, "Please insert a valid email", Toast.LENGTH_SHORT).show();
                else if(superUserEmail.equals(emailDelete.getText().toString()))
                    Toast.makeText(removeUserActivity.this, "You can't delete your own account", Toast.LENGTH_SHORT).show();
                else if(userDb.Deleteuser(emailDelete.getText().toString())>=1 || userDb.DeleteSuperuser(emailDelete.getText().toString())>=1) {
                    Toast.makeText(removeUserActivity.this, "User deleted successfully", Toast.LENGTH_SHORT).show();
                    Intent intent01 = new Intent(getApplicationContext(), UserList.class);
                    startActivity(intent01);
                    finish();
                }
                    else Toast.makeText(removeUserActivity.this, "The user entered does not exist", Toast.LENGTH_SHORT).show();

            }
        });

    }

}
