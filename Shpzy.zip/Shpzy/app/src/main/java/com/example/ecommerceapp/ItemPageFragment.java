package com.example.ecommerceapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class ItemPageFragment extends Fragment implements AdapterView.OnItemSelectedListener{

    TextView itemNameTV;
    ImageView IV;
    TextView priceTV;
    TextView quantityInStock;
    TextView detailsTV;
    TextView categoryTV;
    Button addToCartBtn;
    Button reviewBtn;
    Spinner quantitySpinner;
    RatingBar ratingAvgView;
    TextView reviewNumberTV;
    Button invisibleSearchBtn;
    Button moreReviewsBTN;

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_itempage, container, false);
        Context contextFragment = getActivity();

        //ottieni il valore da ImageAdapter
        String itemId = getArguments().getString("itemid");
        String email = HomeActivity.email;

        IV = rootView.findViewById(R.id.ImageViewItemInPage02);
        itemNameTV = rootView.findViewById(R.id.ItemNameInPage);
        priceTV = rootView.findViewById(R.id.PriceIV);
        quantityInStock = rootView.findViewById(R.id.quantityTV);
        detailsTV = rootView.findViewById(R.id.ItemDetailsTV);
        categoryTV = rootView.findViewById(R.id.itemCategoryTV);

        ItemDb db = new ItemDb(rootView.getContext());

        db.insertCronology(itemId, email);

        HashMap<String,String> item = db.getItemById(Integer.parseInt(itemId));

        String itemName = item.get("name");
        itemNameTV.setText(itemName);

        String itemPrice = item.get("price");
        priceTV.setText(itemPrice+"€");

        String itemQuantity = item.get("quantity");
        quantityInStock.setText(itemQuantity);

        String itemDetails = item.get("details");
        detailsTV.setText(itemDetails);

        String itemCategory = item.get("category");
        categoryTV.setText(itemCategory);

        categoryTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("category", itemCategory);

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment itemSearchedFragment = new ItemsSearchedFragment();
                itemSearchedFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, itemSearchedFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        //Cambio la categoria consigliata a itemCategory
        HomeActivity.categoryRecommended = itemCategory;

        int itemImage = db.getImageById(Integer.parseInt(itemId));
        IV.setImageResource(itemImage);

        addToCartBtn = rootView.findViewById(R.id.AddToCartBtn);

        ItemDb itemDb = new ItemDb(rootView.getContext());

        reviewBtn = rootView.findViewById(R.id.reviewBtnItemPage);

        UserDb reviewDb = new UserDb(contextFragment);
        moreReviewsBTN = rootView.findViewById(R.id.ShowMoreReviewsBTN);

        //////
        ArrayList<HashMap<String, String>> itemList = reviewDb.GetReviewByItem(itemId);
        if(itemList.size() != 0) {
            Random r = new Random();
            HashMap<String, String> review = itemList.get(r.nextInt(itemList.size())); //prendo una recensione random

            TextView userNameTV = rootView.findViewById(R.id.userNameTV);
            RatingBar ratingBar2 = (RatingBar) rootView.findViewById(R.id.ratingBar2);
            TextView reviewByUser = (TextView) rootView.findViewById(R.id.reviewByUser);

            int selectedReview = r.nextInt(itemList.size());

            userNameTV.setText(itemList.get(selectedReview).get("username")
                                + " " + itemList.get(selectedReview).get("usersurname"));
            ratingBar2.setRating(Float.parseFloat(itemList.get(selectedReview).get("ratingstars")));
            reviewByUser.setText(itemList.get(selectedReview).get("review"));
        } else {
            //in questo caso la lista delle recensioni è vuota, quindi non ci sono recensioni
            LinearLayout linearLayoutReviewBTN = rootView.findViewById(R.id.linearLayoutReviewBTN);
            linearLayoutReviewBTN.removeView(moreReviewsBTN);

            ConstraintLayout constraintLayout = rootView.findViewById(R.id.constraintLayout02);
            constraintLayout.removeAllViews();
        }

        Integer[] optionsArray = new Integer[]{1, 2, 3, 4};

        quantitySpinner = rootView.findViewById(R.id.quantitySpinner);
        ArrayAdapter<Integer> adapterSpinner = new ArrayAdapter<Integer>(contextFragment, android.R.layout.simple_spinner_item, optionsArray);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        quantitySpinner.setAdapter(adapterSpinner);

        quantitySpinner.setOnItemSelectedListener(this);

        ratingAvgView = (RatingBar) rootView.findViewById(R.id.ratingAvgView);
        ratingAvgView.setRating(reviewDb.getRatingAvg(Integer.parseInt(itemId)));

        reviewNumberTV = (TextView) rootView.findViewById(R.id.reviewNumberTV);
        reviewNumberTV.setText("(" +reviewDb.getCountReviews(itemId) + ")" );

        addToCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = HomeActivity.email;
                int quantity = Integer.parseInt(String.valueOf(quantitySpinner.getSelectedItem()));
                if( itemDb.insertItemInCart(email, itemId, quantity, Integer.parseInt(itemQuantity)) == true)
                    Toast.makeText(contextFragment, "Added to Shopping Cart", Toast.LENGTH_SHORT).show();
                else Toast.makeText(contextFragment, "The item is already in your cart", Toast.LENGTH_SHORT).show();
            }
        });

        moreReviewsBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment selectedFragment = new MoreReviewsFragment();
                Bundle bundle = new Bundle();
                bundle.putString("itemid", itemId);

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment MoreReviewsFragment = new MoreReviewsFragment();
                MoreReviewsFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, MoreReviewsFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        reviewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();

                bundle.putString("itemid", itemId);

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment reviewFragment = new ReviewFragment();
                reviewFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fragment_container, reviewFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });

        invisibleSearchBtn = (Button) rootView.findViewById(R.id.button_search);

        invisibleSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment selectedFragment = null;

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment searchFragment = new SearchFragment();
                fragmentTransaction.replace(R.id.fragment_container, searchFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return rootView;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}