package com.example.ecommerceapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SuperuserItemActivity extends AppCompatActivity {

    EditText nameItem;
    EditText detailsItem;
    EditText priceItem;
    EditText categoryItem;
    EditText quantityItem;
    Button deleteBtn;
    Button modifyBtn;
    Spinner SpinnerCategory;
    ImageView imageView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.super_user_item_activity);

        Intent intentLogin = getIntent();
        String itemid = intentLogin.getStringExtra("itemid");

        nameItem = (EditText) findViewById(R.id.nameItemModify);
        detailsItem = (EditText) findViewById(R.id.detailsModify);
        priceItem = (EditText) findViewById(R.id.priceModify);
        quantityItem = (EditText) findViewById(R.id.quantityModify);
        deleteBtn = (Button) findViewById(R.id.deleteItemBtn);
        modifyBtn = (Button) findViewById(R.id.modifyItemBtn);
        SpinnerCategory = (Spinner) findViewById(R.id.item_category_spinner02);
        imageView = (ImageView) findViewById(R.id.imageView6);

        ItemDb itemDb = new ItemDb(getApplicationContext());
        ArrayList<HashMap<String, String>> itemList = itemDb.GetItemsByid(Integer.parseInt(itemid));

        imageView.setImageResource(Integer.parseInt(itemList.get(0).get("image_id")));

        List<String> list;
        list = new ArrayList<String>();
        list.add("Clothing");
        list.add("Technology");
        list.add("Food");
        list.add("Accessories");
        list.add("Sport");
        list.add("Gardering");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerCategory.setAdapter(adapter);

        modifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = String.valueOf(nameItem.getText());
                String details = String.valueOf(detailsItem.getText());
                String category = String.valueOf(SpinnerCategory.getSelectedItem());
                String priceStr = String.valueOf(priceItem.getText());
                String quantityStr = String.valueOf(quantityItem.getText());

                if(name.equals("") || details.equals("") || category.equals("") || priceStr.equals("") || quantityStr.equals("")){
                    Toast.makeText(SuperuserItemActivity.this, "Please insert all infos for the item", Toast.LENGTH_SHORT).show();
                } else {
                    ItemDb db = new ItemDb(SuperuserItemActivity.this);
                    db.DeleteItem(Integer.parseInt(itemid));
                    Intent goToItemList = new Intent(getApplicationContext(), ItemList.class);
                    startActivity(goToItemList);
                    finish();
                }
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ItemDb itemDb = new ItemDb(getApplicationContext());
                itemDb.DeleteItem(Integer.parseInt(itemid));
                Intent goToItemList = new Intent(getApplicationContext(), ItemList.class);
                startActivity(goToItemList);
                finish();
            }
        });

    }

}
