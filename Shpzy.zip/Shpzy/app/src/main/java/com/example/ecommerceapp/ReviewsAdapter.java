package com.example.ecommerceapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

public class ReviewsAdapter extends BaseAdapter {

    private Context context;
    private List<HashMap<String, String>> list;

    public ReviewsAdapter(Context context, List<HashMap<String, String>> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.review_item_page_list_row, parent, false);
        }

        TextView username = (TextView) convertView.findViewById(R.id.userNameTV);
        RatingBar ratingBar = (RatingBar) convertView.findViewById(R.id.ratingBar2);
        TextView reviewByUser = (TextView) convertView.findViewById(R.id.reviewByUser);

        HashMap<String, String> item = list.get(position);
        username.setText(item.get("username") + " " + item.get("usersurname"));
        ratingBar.setRating(Float.parseFloat(item.get("ratingstars")));
        reviewByUser.setText(item.get("review"));

        return convertView;
    }
}