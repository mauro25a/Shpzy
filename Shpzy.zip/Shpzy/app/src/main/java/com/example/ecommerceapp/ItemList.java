package com.example.ecommerceapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class ItemList extends AppCompatActivity {

    Button addItemBtn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);

        addItemBtn = (Button) findViewById(R.id.add_item_button_list);

        ItemDb db = new ItemDb(this);

        int listSize = Integer.parseInt(db.GetNumberItems());
        String[] ids = new String[listSize];
        ArrayList<HashMap<String, String>> itemList = db.GetItems();

        String itemId = "";

        for (int position = 0; position < listSize; position++) {
            ids[position] = itemList.get(position).get("itemid");
        }

        ListView lv = (ListView) findViewById(R.id.item_list);

        ListAdapter adapter = new SimpleAdapter(getApplicationContext(), itemList, R.layout.itemlist_row, new String[]{"name","price","category","details","quantity","image_id"}, new int[]{R.id.itemId,R.id.priveTV,R.id.category,R.id.details,R.id.quantityTV,R.id.image_item_inlist});
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                long index = lv.getItemIdAtPosition(position);
                //cerco nella lista di id, l'id che ha come posizione index, ovvero la posizione dell'elemento che ho cliccato
                String itemIdClicked = ids[(int) index];

                Intent intent01 = new Intent(getApplicationContext(), SuperuserItemActivity.class);
                intent01.putExtra("itemid", itemIdClicked);
                startActivity(intent01);
            }
        });

        addItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addItemIntent = new Intent(getApplicationContext(), AddItemActivity.class);
                startActivity(addItemIntent);
                finish();
            }
        });

    }

}
