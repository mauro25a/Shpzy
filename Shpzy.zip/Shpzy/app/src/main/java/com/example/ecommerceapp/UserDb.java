package com.example.ecommerceapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;

public class UserDb extends SQLiteOpenHelper {
    Context context;
        private static final int DB_VERSION = 1;
        private static final String DB_NAME = "userstable";
        private static final String TABLE_Users = "userdetails";
        private static final String KEY_ID = "id";
        private static final String KEY_EMAIL = "email";
        private static final String KEY_PASSWORD = "password";
        private static final String KEY_ORDERS = "orders";
        private static final String KEY_BALANCE = "balance";
        private static final String KEY_ADDRESS = "address";
        private static final String KEY_NAME = "username";
        private static final String KEY_SURNAME = "usersurname";

        //Reviews table attributes
        private static final String TABLE_Reviews = "reviewstable";
        private static final String REVIEW_ID = "idReview";
        private static final String ITEM_REVIEWED_ID = "itemidReviewed";
        private static final String USER_REVIEWER_ID = "userid";
        private static final String REVIEW_TEXT = "review";
        private static final String RATING_STARS = "ratingstars";

        //Items searched (cronology) table attributes
        private static final String TABLE_Cronology = "cronologytable";
        private static final String CRONOLOGY_ID = "id";
        private static final String USER_ID = "userid";
        private static final String SEARCHWORD = "searchword";

        //Superusers table attributes
        private static final String TABLE_Superusers = "superusertable";
        private static final String KEY_ID_SUPERUSER = "id";
        private static final String EMAIL_SUPERUSER = "email";
        private static final String PASSWORD_SUPERUSER = "password";

        public UserDb(Context context) {
            super (context, DB_NAME, null, DB_VERSION);
            //this.context=context;
        }
@Override
public void onCreate (SQLiteDatabase db){
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_Users + " ("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_EMAIL + " TEXT, "
                + KEY_PASSWORD + " TEXT, "
                + KEY_BALANCE + " TEXT, "
                + KEY_ADDRESS + " TEXT,"
                + KEY_NAME + " TEXT,"
                + KEY_SURNAME + " TEXT,"
                + KEY_ORDERS + " TEXT );";
        db.execSQL (CREATE_USERS_TABLE);

        String CREATE_REVIEW_TABLE = "CREATE TABLE " + TABLE_Reviews + " ("
                + REVIEW_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ITEM_REVIEWED_ID + " TEXT, "
                + USER_REVIEWER_ID + " TEXT, "
                + RATING_STARS + " REAL, "
                + REVIEW_TEXT + " TEXT);";
        db.execSQL (CREATE_REVIEW_TABLE);

        String CREATE_CRONOLOGY_TABLE = "CREATE TABLE " + TABLE_Cronology + " ("
                + CRONOLOGY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USER_ID + " TEXT, "
                + SEARCHWORD + " TEXT);";
        db.execSQL (CREATE_CRONOLOGY_TABLE);

        String CREATE_SUPERUSERS_TABLE = "CREATE TABLE " + TABLE_Superusers + " ("
                + KEY_ID_SUPERUSER + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + PASSWORD_SUPERUSER + " TEXT, "
                + EMAIL_SUPERUSER + " TEXT);";
        db.execSQL (CREATE_SUPERUSERS_TABLE);

        //Inserisco il superutente che aggiugerà gli altri superutenti
    db.execSQL("INSERT INTO " + TABLE_Superusers + " (email, password) VALUES ('superuser@email.com', 'superuser')");

    }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
                //Rimuove vecchie tabelle se esistono
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_Users);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_Reviews);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_Cronology);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_Superusers);
                //Crea una nuova tabella
                onCreate(db);
        }

        void insertSuperuser(String email, String password){
            SQLiteDatabase db = this.getWritableDatabase();
            //crea una nuova mappa di valori, dove il nome delle colonne sono le chiavi
            ContentValues cValues = new ContentValues();
            cValues.put(EMAIL_SUPERUSER, email);
            cValues.put(PASSWORD_SUPERUSER, password);
            //inserisci una nuova riga, restituendo il valore di primary key della nuova riga
            long result = db.insert(TABLE_Superusers,null, cValues);
            db.close();
        }

        boolean authSuperuser(String email, String password){
            SQLiteDatabase db = this.getWritableDatabase();
            String query = "SELECT * FROM " + TABLE_Superusers + " WHERE email = '" + email + "' AND password = '" + password + "'";
            Cursor cursor = db.rawQuery(query, null);
            if(cursor.moveToFirst())
                return true;
            return false;
        }

        void insertuserdetails(String email, String password, String orders, String balance, String address, String name, String surname){
                //si accede al Data Repository in modalità scrittura
                SQLiteDatabase db = this.getWritableDatabase();
                //crea una nuova mappa di valori, dove il nome delle colonne sono le chiavi
                ContentValues cValues = new ContentValues();
                cValues.put(KEY_EMAIL, email);
                cValues.put(KEY_ORDERS, orders);
                cValues.put(KEY_PASSWORD, password);
                cValues.put(KEY_BALANCE, balance);
                cValues.put(KEY_ADDRESS, address);
                cValues.put(KEY_NAME, name);
                cValues.put(KEY_SURNAME, surname);
                //inserisci una nuova riga, restituendo il valore di primary key della nuova riga
                long result = db.insert(TABLE_Users,null, cValues);
                db.close();
        }

        void addCronologyWord(String email, String searchword){
            //si accede al Data Repository in modalità scrittura
            SQLiteDatabase db = this.getWritableDatabase();
            //crea una nuova mappa di valori, dove il nome delle colonne sono le chiavi
            ContentValues cValues = new ContentValues();
            cValues.put(USER_ID, email);
            cValues.put(SEARCHWORD, searchword);
            //inserisci una nuova riga, restituendo il valore di primary key della nuova riga
            long result = db.insert(TABLE_Cronology,null, cValues);
            db.close();
        }

        public ArrayList<HashMap<String,String>>GetCronology(String email){
            SQLiteDatabase db = this.getWritableDatabase();
            ArrayList<HashMap<String,String>> cronologyList = new ArrayList<>();
            String query = "SELECT * FROM " + TABLE_Cronology;
            Cursor cursor = db.rawQuery(query, null);

            if(!cursor.moveToFirst())
                return cronologyList;

            while(cursor.moveToNext()){
                HashMap<String,String> cronology = new HashMap<>();
                cronology.put("email", cursor.getString(cursor.getColumnIndex(USER_ID)));
                cronology.put("searchword", cursor.getString(cursor.getColumnIndex(SEARCHWORD)));
                cronologyList.add(cronology);
            }
            return cronologyList;
        }

    public void deleteCronology(String userid, String searchword){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_Cronology, USER_ID + " = ? AND " + SEARCHWORD + " = ?", new String[]{userid, searchword});
        db.close();
    }
/*
    public ArrayList<HashMap<String,String>>GetReviewByUser(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> reviewList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_Users + " a INNER JOIN " + TABLE_Reviews  + " b ON a.email = b.userid"  + " WHERE a.email = '" + email + "'";
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            HashMap<String,String> item = new HashMap<>();
            item.put("review", cursor.getString(cursor.getColumnIndex(REVIEW_TEXT)));
            item.put("ratingstars", cursor.getString(cursor.getColumnIndex(RATING_STARS)));
            item.put("itemidReviewed", cursor.getString(cursor.getColumnIndex(ITEM_REVIEWED_ID)));
            item.put("usarname", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("usersurname", cursor.getString(cursor.getColumnIndex(KEY_SURNAME)));
            reviewList.add(item);
        }
        return reviewList;
    }
 */
        public float getRatingAvg(int itemId){
            SQLiteDatabase db = this.getWritableDatabase();
            String query = "SELECT * FROM " + TABLE_Reviews + " WHERE itemidReviewed = " + itemId;
            Cursor cursor = db.rawQuery(query, null);
            float rating = 0;
            while(cursor.moveToNext()){
                int idColumnIndex = cursor.getColumnIndex("ratingstars");
                rating += cursor.getFloat(idColumnIndex);
            }
            int count = cursor.getCount();
            cursor.close();
            return rating/count;
        }

        public String getCountReviews(String itemId){
            SQLiteDatabase db = this.getWritableDatabase();
            String query = "SELECT * FROM " + TABLE_Reviews + " WHERE itemidReviewed = " + itemId;
            Cursor cursor = db.rawQuery(query, null);
            int count = 0;
            if(cursor.moveToFirst()==true)
                count = cursor.getCount();
            cursor.close();
            return String.valueOf(count);
        }

        void insertReview(String email, String itemid, String reviewText, float ratingStars){
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cValues = new ContentValues();
            cValues.put(USER_REVIEWER_ID, email);
            cValues.put(ITEM_REVIEWED_ID, itemid);
            cValues.put(REVIEW_TEXT, reviewText);
            cValues.put(RATING_STARS, ratingStars);
            long result = db.insert(TABLE_Reviews,null, cValues);
            db.close();
        }

    public ArrayList<HashMap<String,String>>GetReviewByUser(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> reviewList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_Users + " a INNER JOIN " + TABLE_Reviews  + " b ON a.email = b.userid"  + " WHERE a.email = '" + email + "'";
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            HashMap<String,String> item = new HashMap<>();
            item.put("review", cursor.getString(cursor.getColumnIndex(REVIEW_TEXT)));
            item.put("ratingstars", cursor.getString(cursor.getColumnIndex(RATING_STARS)));
            item.put("itemidReviewed", cursor.getString(cursor.getColumnIndex(ITEM_REVIEWED_ID)));
            item.put("usarname", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("usersurname", cursor.getString(cursor.getColumnIndex(KEY_SURNAME)));
            reviewList.add(item);
        }
        return reviewList;
    }

    public ArrayList<HashMap<String,String>>GetReviewByItem(String itemid){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> reviewList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_Users + " a INNER JOIN " + TABLE_Reviews  + " b ON a.email = b.userid"  + " WHERE b.itemidReviewed = '" + itemid + "'";
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            HashMap<String,String> item = new HashMap<>();
            item.put("review", cursor.getString(cursor.getColumnIndex(REVIEW_TEXT)));
            item.put("ratingstars", cursor.getString(cursor.getColumnIndex(RATING_STARS)));
            item.put("email", cursor.getString(cursor.getColumnIndex(KEY_EMAIL)));
            item.put("username", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            item.put("usersurname", cursor.getString(cursor.getColumnIndex(KEY_SURNAME)));
            reviewList.add(item);
        }
        return reviewList;
    }

    public String GetUsersCount(){
        int count = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_Users;
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()) count = cursor.getInt(0);
        else count = 0;
        cursor.close();
        db.close();
        return String.valueOf(count);
    }

    public String GetReviewsNumber(){
        int count = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_Reviews;
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()) count = cursor.getInt(0);
        else count = 0;
        cursor.close();
        db.close();
        return String.valueOf(count);
    }

        public ArrayList<HashMap<String,String>>Getusers(){
                SQLiteDatabase db = this.getWritableDatabase();
                ArrayList<HashMap<String,String>> userList = new ArrayList<>();
                String query = "SELECT email, password, balance, orders, address, username, usersurname FROM " + TABLE_Users;
                Cursor cursor = db.rawQuery(query, null);
                while(cursor.moveToNext()){
                        HashMap<String,String> user = new HashMap<>();
                        user.put("email", cursor.getString(cursor.getColumnIndex(KEY_EMAIL)));
                        user.put("password", cursor.getString(cursor.getColumnIndex(KEY_PASSWORD)));
                        user.put("balance", cursor.getString(cursor.getColumnIndex(KEY_BALANCE)));
                        user.put("orders", cursor.getString(cursor.getColumnIndex(KEY_ORDERS)));
                        user.put("address", cursor.getString(cursor.getColumnIndex(KEY_ADDRESS)));
                        user.put("username", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
                        user.put("usersurname", cursor.getString(cursor.getColumnIndex(KEY_SURNAME)));
                        userList.add(user);
                }
                return userList;
        }

    public ArrayList<HashMap<String,String>>GetSuperusers(){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> userList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_Superusers;
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            HashMap<String,String> user = new HashMap<>();
            user.put("email", cursor.getString(cursor.getColumnIndex(KEY_EMAIL)));
            user.put("password", cursor.getString(cursor.getColumnIndex(KEY_PASSWORD)));
            userList.add(user);
        }
        return userList;
    }

    @SuppressLint("Range")
    public ArrayList<HashMap<String,String>>GetusersByid(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String,String>> userList = new ArrayList<>();
        Cursor cursor = db.query(TABLE_Users, new String[]{KEY_ID,KEY_BALANCE, KEY_ORDERS, KEY_PASSWORD, KEY_ADDRESS, KEY_NAME, KEY_SURNAME}, KEY_EMAIL+"=?", new String[]{String.valueOf(email)},null,null,null, null);
        if(cursor.moveToNext()){
            HashMap<String,String> user = new HashMap<>();
            user.put("id", cursor.getString(cursor.getColumnIndex(KEY_ID)));
            user.put("password", cursor.getString(cursor.getColumnIndex(KEY_PASSWORD)));
            user.put("balance", cursor.getString(cursor.getColumnIndex(KEY_BALANCE)));
            user.put("orders", cursor.getString(cursor.getColumnIndex(KEY_ORDERS)));
            user.put("address", cursor.getString(cursor.getColumnIndex(KEY_ADDRESS)));
            user.put("username", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            user.put("usersurname", cursor.getString(cursor.getColumnIndex(KEY_SURNAME)));
            userList.add(user);
        }
        return userList;
    }

    HashMap<String, String> getUserByEmail(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * from " + TABLE_Users + " where email =?", new String[]{email});
        HashMap<String,String> user = new HashMap<>();
        user.put("balance", cursor.getString(cursor.getColumnIndex(KEY_BALANCE)));
        user.put("orders", cursor.getString(cursor.getColumnIndex(KEY_ORDERS)));
        user.put("address", cursor.getString(cursor.getColumnIndex(KEY_ADDRESS)));
        user.put("username", cursor.getString(cursor.getColumnIndex(KEY_NAME)));
        user.put("usersurname", cursor.getString(cursor.getColumnIndex(KEY_SURNAME)));
        return user;
    }

    public int incrementOrders(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * from " + TABLE_Users + " where email =?", new String[]{email});
        HashMap<String,String> user = new HashMap<>();
        int orders = Integer.parseInt(String.valueOf(cursor.getColumnIndex("orders")));
        orders++;
        return orders;
    }

    public int Deleteuser(String userid){
            SQLiteDatabase db = this.getWritableDatabase();
            int count = db.delete(TABLE_Users, KEY_EMAIL + " = ?", new String[]{String.valueOf(userid)});
            db.close();
            return count;
    }

    public int DeleteSuperuser(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        int count = db.delete(TABLE_Superusers, EMAIL_SUPERUSER + " = ?", new String[]{String.valueOf(email)});
        db.close();
        return count;
    }

    public void Updateuserdetails(String oldEmail, String email, String password, String address, String name, String surname){
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cVals = new ContentValues();
            cVals.put(KEY_EMAIL, email);
            cVals.put(KEY_PASSWORD, password);
            cVals.put(KEY_ADDRESS, address);
            cVals.put(KEY_NAME, name);
            cVals.put(KEY_SURNAME, surname);
            db.update(TABLE_Users, cVals, "email = ?", new String[] { oldEmail });

            ContentValues cronologyVals = new ContentValues();
            cronologyVals.put(USER_ID, email);
            db.update(TABLE_Cronology, cronologyVals, "userid = ?", new String[] { oldEmail });

            ContentValues reviewVals = new ContentValues();
            reviewVals.put(USER_REVIEWER_ID, email);
            db.update(TABLE_Reviews, reviewVals, "userid = ?", new String[] { oldEmail });
        }

    public void updateBalance(String balance, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cVals = new ContentValues();
        cVals.put(KEY_BALANCE, balance);
        db.update(TABLE_Users, cVals, KEY_EMAIL + " =?", new String[]{email});
    }



    public boolean searchUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * from " + TABLE_Users + " where email =?", new String[]{email});
        if(cursor.moveToNext()){
            int emailIndex = cursor.getColumnIndex("email");
            if( cursor.getString(emailIndex).equals(email) ){
                int passwordIndex = cursor.getColumnIndex("password");
                if(cursor.getString(passwordIndex).equals(password)) {
                    cursor.close();
                    return true;
                }
            }
        }
        cursor.close();
        return false;
    }

    public boolean searchUser(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * from " + TABLE_Users + " where email =?", new String[]{email});
        if(cursor.getCount()>0) return true;
        return false;
    }

    public boolean searchSuperser(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * from " + TABLE_Superusers + " where email =?", new String[]{email});
        if(cursor.getCount()>0) return true;
        return false;
    }

}