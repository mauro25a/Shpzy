package com.example.ecommerceapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.HashMap;

public class AccountFragment extends Fragment{

    TextView EmailTV;
    TextView balanceTV;
    TextView nameTV;
    TextView surnameTV;
    TextView addressTV;
    Button addFunds;
    Button modifyAccount;
    Button invisibleSearchBtn;
    int balance = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_account, container, false);
        Context contextFragment = getActivity();

        EmailTV = (TextView) rootView.findViewById(R.id.accountEmailTV);
        nameTV = (TextView) rootView.findViewById(R.id.nameAccontFragment);
        surnameTV = (TextView) rootView.findViewById(R.id.surnameAccountFragment);
        addressTV = (TextView) rootView.findViewById(R.id.addressAccountFragment);

        String email = HomeActivity.email;
        EmailTV.setText("Email: " + email);

        UserDb db = new UserDb(contextFragment);

        ArrayList<HashMap<String,String>> userList = db.GetusersByid(email);

        String name = userList.get(0).get("username");
        String surname = userList.get(0).get("usersurname");
        String address = userList.get(0).get("address");

        nameTV.setText(name);
        surnameTV.setText(surname);
        addressTV.setText(address);

        ArrayList<HashMap<String, String>> itemList = db.GetReviewByUser(email);
        ListView lv = (ListView) rootView.findViewById(R.id.listReviewsByUser);
        ListAdapter adapter = new SimpleAdapter(contextFragment, itemList, R.layout.review_list_row, new String[]{"ratingstars","review"},new int[]{R.id.ratingStarTV,R.id.reviewTextAccount});
        lv.setAdapter(adapter);

        balanceTV = (TextView) rootView.findViewById(R.id.balanceTV);

        balance = Integer.parseInt(userList.get(0).get("balance"));
        balanceTV.setText(String.valueOf(balance));

        addFunds = rootView.findViewById(R.id.addFundsBtn);

        addFunds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                balance += 200;
                db.updateBalance(String.valueOf(balance), email);
                balanceTV.setText(String.valueOf(balance));
            }
        });

        modifyAccount = (Button) rootView.findViewById(R.id.modifyAccountBtn);
        modifyAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent01 = new Intent(getContext(), modifyAccountActivity.class);
                intent01.putExtra("email", email);
                startActivity(intent01);
            }
        });

        invisibleSearchBtn = (Button) rootView.findViewById(R.id.button_search);

        invisibleSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment selectedFragment = null;

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Fragment searchFragment = new SearchFragment();
                fragmentTransaction.replace(R.id.fragment_container, searchFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });

        return rootView;
    }


}
