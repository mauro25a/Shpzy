package com.example.ecommerceapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import java.util.ArrayList;
import java.util.HashMap;

public class cronologyAdapter extends BaseAdapter {
    private ArrayList<HashMap<String, String>> mData;
    private Context mContext;
    private FragmentManager fragmentManager;

    public cronologyAdapter(Context context, FragmentManager fragmentManager, ArrayList<HashMap<String, String>> cronologyList) {
        super();
        mContext = context;
        mData = cronologyList;
        this.fragmentManager=fragmentManager;
    }
    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.cronology_item_row, parent, false);

        String searchWord = mData.get(position).get("searchword");

        TextView itemSearched = (TextView) convertView.findViewById(R.id.cronologyItemRow);
        ImageView removeBtn = (ImageView) convertView.findViewById(R.id.removeCronology);

        itemSearched.setText(searchWord);

        removeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserDb userDb = new UserDb(mContext);
                userDb.deleteCronology(HomeActivity.email, searchWord);

                Fragment selectedFragment = new SearchFragment();
                fragmentManager.beginTransaction().replace(R.id.fragment_container,
                        selectedFragment).commit();
            }
        });

        itemSearched.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("searchWord", searchWord);

                Fragment selectedFragment = new ItemsSearchedFragment();
                // Imposta il bundle come argomento del fragment
                selectedFragment.setArguments(bundle);
                fragmentManager.beginTransaction().replace(R.id.fragment_container,
                        selectedFragment).commit();
            }
        });

        return convertView;
    }
}
